#!/usr/bin/env python3
"""
XAUUSD 24/7 TRADING ANALYZER - XM ARABIA EDITION
===================================================
Analyse technique complete de l'or (XAU/USD) avec detection automatique
de setups haute qualite et envoi de rapports par email.

Compatible avec le broker XM Arabia (xmarabia.net)
Horaires GOLD XM: Lun 01:05 - Ven 23:50 (GMT+2)

Usage:
    python xauusd_analyzer.py

Configuration:
    Editez la section CONFIGURATION ci-dessous avec vos parametres email.
"""

import yfinance as yf
import pandas as pd
import numpy as np
import smtplib
import ssl
import time
import json
import os
import logging
from datetime import datetime, timedelta, timezone
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dataclasses import dataclass, asdict
from typing import List, Optional, Dict, Tuple
from enum import Enum
import threading
import signal
import sys

# ============================================================================
# CONFIGURATION - MODIFIEZ CES PARAMETRES
# ============================================================================

def load_config():
    """Charge la configuration depuis config.json"""
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
    
    default_config = {
        "smtp_host": "smtp.gmail.com",
        "smtp_port": 587,
        "smtp_username": "",
        "smtp_password": "",
        "recipient_email": "",
        "min_confidence": 65,
        "check_interval_minutes": 5,
        "analyze_asian": True,
        "analyze_european": True,
        "analyze_american": True,
        "only_overlap_sessions": False,
        "xm_gmt_offset": 2,
        "rsi_overbought": 70,
        "rsi_oversold": 30,
        "atr_multiplier_sl": 2.0,
        "atr_multiplier_tp1": 2.5,
        "atr_multiplier_tp2": 4.0,
        "atr_multiplier_tp3": 6.0,
        "log_level": "INFO",
        "data_source": "yahoo",
        "save_reports": True,
        "reports_directory": "./reports"
    }
    
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                user_config = json.load(f)
                default_config.update(user_config)
                print(f"[CONFIG] Chargee depuis: {config_path}")
        except Exception as e:
            print(f"[CONFIG] Erreur lecture config.json: {e}. Utilisation config par defaut.")
    else:
        print("[CONFIG] config.json non trouve. Utilisation configuration par defaut.")
        print("[CONFIG] Creez un fichier config.json pour personnaliser les parametres.")
    
    return default_config

CONFIG = load_config()

# ============================================================================
# CLASSES & ENUMS
# ============================================================================

class SignalType(Enum):
    BULLISH = "bullish"
    BEARISH = "bearish"
    NEUTRAL = "neutral"

class SetupType(Enum):
    BREAKOUT = "breakout"
    REVERSAL = "reversal"
    TREND_CONTINUATION = "trend_continuation"
    RANGE = "range"
    DIVERGENCE = "divergence"

class TradingSession(Enum):
    ASIAN = "asian"         # 00:00 - 09:00 GMT
    EUROPEAN = "european"   # 08:00 - 17:00 GMT
    AMERICAN = "american"   # 13:00 - 22:00 GMT
    OVERLAP_EU_US = "overlap_eu_us"  # 13:00 - 17:00 GMT (meilleure liquidite)
    CLOSED = "closed"

@dataclass
class TradingSetup:
    id: str
    type: str
    direction: str
    timeframe: str
    entry_price: float
    stop_loss: float
    take_profit_1: float
    take_profit_2: float
    take_profit_3: float
    risk_reward_ratio: float
    confidence: float
    indicators: List[str]
    description: str
    timestamp: str
    session: str
    price_at_detection: float

@dataclass
class AnalysisReport:
    id: str
    timestamp: str
    current_price: float
    daily_change: float
    daily_change_percent: float
    trend: str
    trend_strength: float
    trend_direction_ema: str
    setups: List[TradingSetup]
    rsi: float
    rsi_status: str
    macd: float
    macd_signal: float
    macd_histogram: float
    macd_status: str
    ema_20: float
    ema_50: float
    ema_200: float
    bb_upper: float
    bb_middle: float
    bb_lower: float
    atr: float
    stochastic_k: float
    stochastic_d: float
    stochastic_status: str
    cci: float
    williams_r: float
    support_levels: List[float]
    resistance_levels: List[float]
    recommendation: str
    risk_level: str
    forecast_24h: str
    session: str
    is_xm_market_open: bool
    xm_server_time: str
    next_analysis_in: int

# ============================================================================
# LOGGING
# ============================================================================

logging.basicConfig(
    level=getattr(logging, CONFIG["log_level"]),
    format='%(asctime)s | %(levelname)-8s | %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    handlers=[
        logging.FileHandler('xauusd_analyzer.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('XAUUSD_ANALYZER')

# ============================================================================
# GESTION DES DONNEES MARCHE
# ============================================================================

class MarketDataManager:
    """Gestion des donnees de marche XAU/USD"""
    
    @staticmethod
    def fetch_data(period: str = "5d", interval: str = "5m") -> Optional[pd.DataFrame]:
        """Recupere les donnees XAU/USD depuis Yahoo Finance"""
        try:
            if CONFIG["data_source"] == "simulate":
                return MarketDataManager._generate_simulated_data()
            
            ticker = yf.Ticker("GC=F")  # Gold Futures
            df = ticker.history(period=period, interval=interval)
            
            if df.empty:
                logger.warning("Donnees vides, utilisation des donnees simulees")
                return MarketDataManager._generate_simulated_data()
            
            logger.info(f"Donnees recuperees: {len(df)} bougies | Prix actuel: ${df['Close'].iloc[-1]:.2f}")
            return df
            
        except Exception as e:
            logger.error(f"Erreur recuperation donnees: {e}")
            return MarketDataManager._generate_simulated_data()
    
    @staticmethod
    def fetch_multi_timeframe() -> Dict[str, pd.DataFrame]:
        """Recupere les donnees sur plusieurs timeframes"""
        timeframes = {
            "H1": ("1mo", "1h"),
            "H4": ("3mo", "4h"),
            "D1": ("1y", "1d")
        }
        
        data = {}
        for tf, (period, interval) in timeframes.items():
            logger.debug(f"Recuperation {tf} ({period}/{interval})")
            df = MarketDataManager.fetch_data(period, interval)
            if df is not None:
                data[tf] = df
            time.sleep(2)  # Delai pour eviter le rate limiting Yahoo Finance
        
        return data
    
    @staticmethod
    def get_current_price() -> float:
        """Recupere le prix actuel de XAU/USD"""
        try:
            ticker = yf.Ticker("GC=F")
            info = ticker.info
            return info.get('regularMarketPrice', 0)
        except:
            df = MarketDataManager.fetch_data(period="1d", interval="1m")
            if df is not None and not df.empty:
                return float(df['Close'].iloc[-1])
            return 0.0
    
    @staticmethod
    def _generate_simulated_data() -> pd.DataFrame:
        """Genere des donnees simulees realistes pour XAU/USD"""
        np.random.seed(42)
        n = 500
        
        base_price = 3320  # Prix realiste XAU/USD (mai 2026)
        prices = []
        price = base_price
        
        for i in range(n):
            # Volatilite realiste: ~$0.80 par periode de 5min
            drift = np.random.normal(0, 0.8)
            # Occasional bigger move (2% chance)
            big_move = np.random.normal(0, 3.2) if np.random.random() < 0.02 else 0
            price += drift + big_move
            prices.append(price)
        
        now = datetime.now()
        timestamps = [now - timedelta(minutes=5*(n-i)) for i in range(n)]
        
        df = pd.DataFrame({
            'Open': [p - abs(np.random.randn()) for p in prices],
            'High': [p + abs(np.random.randn()) * 2 for p in prices],
            'Low': [p - abs(np.random.randn()) * 2 for p in prices],
            'Close': prices,
            'Volume': [int(np.random.uniform(1000, 10000)) for _ in range(n)]
        }, index=timestamps)
        
        logger.info(f"Donnees simulees generees: {len(df)} bougies | Prix: ${df['Close'].iloc[-1]:.2f}")
        return df

# ============================================================================
# INDICATEURS TECHNIQUES
# ============================================================================

class TechnicalIndicators:
    """Calcul des indicateurs techniques"""
    
    @staticmethod
    def rsi(data: pd.Series, period: int = 14) -> float:
        """RSI (Relative Strength Index)"""
        delta = data.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return float(rsi.iloc[-1]) if not rsi.empty else 50.0
    
    @staticmethod
    def macd(data: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[float, float, float]:
        """MACD (Moving Average Convergence Divergence)"""
        ema_fast = data.ewm(span=fast).mean()
        ema_slow = data.ewm(span=slow).mean()
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=signal).mean()
        histogram = macd_line - signal_line
        
        return (
            float(macd_line.iloc[-1]),
            float(signal_line.iloc[-1]),
            float(histogram.iloc[-1])
        )
    
    @staticmethod
    def bollinger_bands(data: pd.Series, period: int = 20, std_dev: int = 2) -> Tuple[float, float, float]:
        """Bollinger Bands"""
        middle = data.rolling(window=period).mean()
        std = data.rolling(window=period).std()
        upper = middle + (std * std_dev)
        lower = middle - (std * std_dev)
        
        return (
            float(upper.iloc[-1]),
            float(middle.iloc[-1]),
            float(lower.iloc[-1])
        )
    
    @staticmethod
    def ema(data: pd.Series, period: int) -> float:
        """EMA (Exponential Moving Average)"""
        return float(data.ewm(span=period).mean().iloc[-1])
    
    @staticmethod
    def atr(df: pd.DataFrame, period: int = 14) -> float:
        """ATR (Average True Range)"""
        high_low = df['High'] - df['Low']
        high_close = np.abs(df['High'] - df['Close'].shift())
        low_close = np.abs(df['Low'] - df['Close'].shift())
        tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        return float(tr.rolling(window=period).mean().iloc[-1])
    
    @staticmethod
    def stochastic(df: pd.DataFrame, k_period: int = 14, d_period: int = 3) -> Tuple[float, float]:
        """Stochastic Oscillator"""
        lowest_low = df['Low'].rolling(window=k_period).min()
        highest_high = df['High'].rolling(window=k_period).max()
        k = 100 * (df['Close'] - lowest_low) / (highest_high - lowest_low)
        d = k.rolling(window=d_period).mean()
        
        return float(k.iloc[-1]), float(d.iloc[-1])
    
    @staticmethod
    def cci(df: pd.DataFrame, period: int = 20) -> float:
        """CCI (Commodity Channel Index)"""
        tp = (df['High'] + df['Low'] + df['Close']) / 3
        sma_tp = tp.rolling(window=period).mean()
        mean_dev = tp.rolling(window=period).apply(lambda x: np.abs(x - x.mean()).mean())
        cci = (tp - sma_tp) / (0.015 * mean_dev)
        return float(cci.iloc[-1])
    
    @staticmethod
    def williams_r(df: pd.DataFrame, period: int = 14) -> float:
        """Williams %R"""
        highest_high = df['High'].rolling(window=period).max()
        lowest_low = df['Low'].rolling(window=period).min()
        wr = -100 * (highest_high - df['Close']) / (highest_high - lowest_low)
        return float(wr.iloc[-1])
    
    @staticmethod
    def volume_sma(df: pd.DataFrame, period: int = 20) -> float:
        """Volume SMA"""
        return float(df['Volume'].rolling(window=period).mean().iloc[-1])

# ============================================================================
# DETECTION DE SETUPS HAUTE QUALITE
# ============================================================================

class SetupDetector:
    """Detection de setups de trading haute qualite"""
    
    HIGH_CONFIDENCE = 80
    MEDIUM_CONFIDENCE = 65
    LOW_CONFIDENCE = 50
    
    @staticmethod
    def detect_all_setups(df: pd.DataFrame, timeframe: str, session: str) -> List[TradingSetup]:
        """Detecte tous les setups sur un timeframe donne"""
        setups = []
        
        closes = df['Close']
        current_price = float(closes.iloc[-1])
        atr_val = TechnicalIndicators.atr(df)
        
        # Setup 1: RSI Divergence (Reversal)
        rsi_setup = SetupDetector._detect_rsi_setup(df, closes, current_price, atr_val, timeframe, session)
        if rsi_setup:
            setups.append(rsi_setup)
        
        # Setup 2: MACD Crossover (Trend)
        macd_setup = SetupDetector._detect_macd_setup(df, closes, current_price, atr_val, timeframe, session)
        if macd_setup:
            setups.append(macd_setup)
        
        # Setup 3: Bollinger Bands Squeeze/Breakout
        bb_setup = SetupDetector._detect_bb_setup(df, closes, current_price, atr_val, timeframe, session)
        if bb_setup:
            setups.append(bb_setup)
        
        # Setup 4: EMA Golden/Death Cross
        ema_setup = SetupDetector._detect_ema_setup(df, closes, current_price, atr_val, timeframe, session)
        if ema_setup:
            setups.append(ema_setup)
        
        # Setup 5: Breakout des niveaux cles
        breakout_setup = SetupDetector._detect_breakout_setup(df, closes, current_price, atr_val, timeframe, session)
        if breakout_setup:
            setups.append(breakout_setup)
        
        # Setup 6: Stochastic Reversal
        stoch_setup = SetupDetector._detect_stochastic_setup(df, closes, current_price, atr_val, timeframe, session)
        if stoch_setup:
            setups.append(stoch_setup)
        
        return sorted(setups, key=lambda x: x.confidence, reverse=True)
    
    @staticmethod
    def _detect_rsi_setup(df, closes, price, atr, tf, session) -> Optional[TradingSetup]:
        """Setup RSI Overbought/Oversold avec confirmation"""
        rsi = TechnicalIndicators.rsi(closes)
        ema20 = TechnicalIndicators.ema(closes, 20)
        ema50 = TechnicalIndicators.ema(closes, 50)
        
        direction = None
        confidence = 0
        desc = ""
        
        # RSI Oversold + prix au-dessus EMA20 = BUY signal fort
        if rsi < CONFIG["rsi_oversold"]:
            if price > ema20 and ema20 > ema50:
                direction = SignalType.BULLISH
                confidence = 85
                desc = f"RSI en survente ({rsi:.1f}) avec confirmation haussiere EMA20>EMA50"
            elif price > ema20:
                direction = SignalType.BULLISH
                confidence = 72
                desc = f"RSI en survente ({rsi:.1f}) avec prix au-dessus EMA20"
            else:
                direction = SignalType.BULLISH
                confidence = 60
                desc = f"RSI en survente ({rsi:.1f}) - possible rebond"
        
        # RSI Overbought + prix sous EMA20 = SELL signal fort
        elif rsi > CONFIG["rsi_overbought"]:
            if price < ema20 and ema20 < ema50:
                direction = SignalType.BEARISH
                confidence = 85
                desc = f"RSI en surachat ({rsi:.1f}) avec confirmation baissiere EMA20<EMA50"
            elif price < ema20:
                direction = SignalType.BEARISH
                confidence = 72
                desc = f"RSI en surachat ({rsi:.1f}) avec prix sous EMA20"
            else:
                direction = SignalType.BEARISH
                confidence = 60
                desc = f"RSI en surachat ({rsi:.1f}) - possible correction"
        
        if direction is None or confidence < CONFIG["min_confidence"]:
            return None
        
        return SetupDetector._create_setup(
            SetupType.REVERSAL, direction, tf, price, atr, confidence,
            ["RSI", "EMA 20", "EMA 50"], desc, session
        )
    
    @staticmethod
    def _detect_macd_setup(df, closes, price, atr, tf, session) -> Optional[TradingSetup]:
        """Setup MACD Crossover"""
        macd, signal, hist = TechnicalIndicators.macd(closes)
        ema50 = TechnicalIndicators.ema(closes, 50)
        
        direction = None
        confidence = 0
        desc = ""
        
        # MACD croise au-dessus du signal (bullish)
        if hist > 0 and abs(hist) > 0.01:
            if macd > 0 and price > ema50:
                direction = SignalType.BULLISH
                confidence = 82
                desc = f"MACD haussier confirme (hist: +{hist:.4f}) avec prix au-dessus EMA50"
            else:
                direction = SignalType.BULLISH
                confidence = 68
                desc = f"MACD croisement haussier detecte (hist: +{hist:.4f})"
        
        # MACD croise sous le signal (bearish)
        elif hist < 0 and abs(hist) > 0.01:
            if macd < 0 and price < ema50:
                direction = SignalType.BEARISH
                confidence = 82
                desc = f"MACD baissier confirme (hist: {hist:.4f}) avec prix sous EMA50"
            else:
                direction = SignalType.BEARISH
                confidence = 68
                desc = f"MACD croisement baissier detecte (hist: {hist:.4f})"
        
        if direction is None or confidence < CONFIG["min_confidence"]:
            return None
        
        return SetupDetector._create_setup(
            SetupType.TREND_CONTINUATION, direction, tf, price, atr, confidence,
            ["MACD", "Signal Line", "EMA 50"], desc, session
        )
    
    @staticmethod
    def _detect_bb_setup(df, closes, price, atr, tf, session) -> Optional[TradingSetup]:
        """Setup Bollinger Bands"""
        upper, middle, lower = TechnicalIndicators.bollinger_bands(closes)
        rsi = TechnicalIndicators.rsi(closes)
        
        direction = None
        confidence = 0
        desc = ""
        
        # Prix touche bande inferieure + RSI oversold
        if price < lower:
            if rsi < 35:
                direction = SignalType.BULLISH
                confidence = 88
                desc = f"Prix sous bande inferieure + RSI faible ({rsi:.1f}) - Mean reversion"
            else:
                direction = SignalType.BULLISH
                confidence = 70
                desc = f"Prix sous bande inferieure - rebond potentiel"
        
        # Prix touche bande superieure + RSI overbought
        elif price > upper:
            if rsi > 65:
                direction = SignalType.BEARISH
                confidence = 88
                desc = f"Prix au-dessus bande superieure + RSI eleve ({rsi:.1f}) - Mean reversion"
            else:
                direction = SignalType.BEARISH
                confidence = 70
                desc = f"Prix au-dessus bande superieure - correction potentielle"
        
        if direction is None or confidence < CONFIG["min_confidence"]:
            return None
        
        return SetupDetector._create_setup(
            SetupType.RANGE, direction, tf, price, atr, confidence,
            ["Bollinger Bands", "RSI"], desc, session
        )
    
    @staticmethod
    def _detect_ema_setup(df, closes, price, atr, tf, session) -> Optional[TradingSetup]:
        """Setup EMA Crossover"""
        ema20 = TechnicalIndicators.ema(closes, 20)
        ema50 = TechnicalIndicators.ema(closes, 50)
        ema200 = TechnicalIndicators.ema(closes, 200)
        
        direction = None
        confidence = 0
        desc = ""
        
        # Golden Cross (EMA20 > EMA50) avec confirmation EMA200
        if ema20 > ema50 and price > ema20:
            if price > ema200:
                direction = SignalType.BULLISH
                confidence = 90
                desc = f"Golden Cross confirme! EMA20({ema20:.2f}) > EMA50({ema50:.2f}) | Prix > EMA200 - Tendance haussiere forte"
            else:
                direction = SignalType.BULLISH
                confidence = 75
                desc = f"Golden Cross EMA20 > EMA50 - Momentum haussier"
        
        # Death Cross (EMA20 < EMA50) avec confirmation EMA200
        elif ema20 < ema50 and price < ema20:
            if price < ema200:
                direction = SignalType.BEARISH
                confidence = 90
                desc = f"Death Cross confirme! EMA20({ema20:.2f}) < EMA50({ema50:.2f}) | Prix < EMA200 - Tendance baissiere forte"
            else:
                direction = SignalType.BEARISH
                confidence = 75
                desc = f"Death Cross EMA20 < EMA50 - Momentum baissier"
        
        if direction is None or confidence < CONFIG["min_confidence"]:
            return None
        
        return SetupDetector._create_setup(
            SetupType.TREND_CONTINUATION, direction, tf, price, atr, confidence,
            ["EMA 20", "EMA 50", "EMA 200"], desc, session
        )
    
    @staticmethod
    def _detect_breakout_setup(df, closes, price, atr, tf, session) -> Optional[TradingSetup]:
        """Setup Breakout des niveaux cles"""
        highs = df['High'].tail(50)
        lows = df['Low'].tail(50)
        
        # Trouver les niveaux cles
        resistance = highs.max()
        support = lows.min()
        
        direction = None
        confidence = 0
        desc = ""
        entry_price = price
        
        # Breakout de resistance
        distance_to_resistance = abs(resistance - price) / price
        if distance_to_resistance < 0.001:  # Proche de la resistance
            volume_current = df['Volume'].iloc[-1]
            volume_avg = df['Volume'].tail(20).mean()
            
            if volume_current > volume_avg * 1.2:  # Volume confirme
                direction = SignalType.BULLISH
                confidence = 78
                entry_price = resistance
                desc = f"Breakout de resistance {resistance:.2f} avec volume confirme!"
        
        # Breakdown de support
        distance_to_support = abs(price - support) / price
        if distance_to_support < 0.001:
            volume_current = df['Volume'].iloc[-1]
            volume_avg = df['Volume'].tail(20).mean()
            
            if volume_current > volume_avg * 1.2:
                direction = SignalType.BEARISH
                confidence = 78
                entry_price = support
                desc = f"Breakdown de support {support:.2f} avec volume confirme!"
        
        if direction is None or confidence < CONFIG["min_confidence"]:
            return None
        
        return SetupDetector._create_setup(
            SetupType.BREAKOUT, direction, tf, entry_price, atr, confidence,
            ["Support/Resistance", "Volume"], desc, session
        )
    
    @staticmethod
    def _detect_stochastic_setup(df, closes, price, atr, tf, session) -> Optional[TradingSetup]:
        """Setup Stochastic Overbought/Oversold"""
        k, d = TechnicalIndicators.stochastic(df)
        
        direction = None
        confidence = 0
        desc = ""
        
        # Stochastic oversold (K < 20) = BUY
        if k < 20:
            if k > d:  # K croise D vers le haut
                direction = SignalType.BULLISH
                confidence = 82
                desc = f"Stochastic croisement haussier en zone de survente (%K: {k:.1f})"
            else:
                direction = SignalType.BULLISH
                confidence = 65
                desc = f"Stochastic en survente (%K: {k:.1f}) - rebond attendu"
        
        # Stochastic overbought (K > 80) = SELL
        elif k > 80:
            if k < d:  # K croise D vers le bas
                direction = SignalType.BEARISH
                confidence = 82
                desc = f"Stochastic croisement baissier en zone de surachat (%K: {k:.1f})"
            else:
                direction = SignalType.BEARISH
                confidence = 65
                desc = f"Stochastic en surachat (%K: {k:.1f}) - correction attendue"
        
        if direction is None or confidence < CONFIG["min_confidence"]:
            return None
        
        return SetupDetector._create_setup(
            SetupType.REVERSAL, direction, tf, price, atr, confidence,
            ["Stochastic %K", "Stochastic %D"], desc, session
        )
    
    @staticmethod
    def _create_setup(setup_type, direction, tf, price, atr, confidence, indicators, desc, session) -> TradingSetup:
        """Cree un objet TradingSetup"""
        is_bullish = direction == SignalType.BULLISH
        
        sl = price - (atr * CONFIG["atr_multiplier_sl"]) if is_bullish else price + (atr * CONFIG["atr_multiplier_sl"])
        tp1 = price + (atr * CONFIG["atr_multiplier_tp1"]) if is_bullish else price - (atr * CONFIG["atr_multiplier_tp1"])
        tp2 = price + (atr * CONFIG["atr_multiplier_tp2"]) if is_bullish else price - (atr * CONFIG["atr_multiplier_tp2"])
        tp3 = price + (atr * CONFIG["atr_multiplier_tp3"]) if is_bullish else price - (atr * CONFIG["atr_multiplier_tp3"])
        
        rr = abs(tp1 - price) / abs(sl - price) if sl != price else 0
        
        return TradingSetup(
            id=f"{setup_type.value}-{direction.value}-{int(time.time()*1000)}",
            type=setup_type.value,
            direction=direction.value,
            timeframe=tf,
            entry_price=round(price, 2),
            stop_loss=round(sl, 2),
            take_profit_1=round(tp1, 2),
            take_profit_2=round(tp2, 2),
            take_profit_3=round(tp3, 2),
            risk_reward_ratio=round(rr, 2),
            confidence=round(confidence, 1),
            indicators=indicators,
            description=desc,
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            session=session,
            price_at_detection=round(price, 2)
        )

# ============================================================================
# GESTION DES SESSIONS ET HORAIRES XM
# ============================================================================

class XMMarketHours:
    """Gestion des horaires de trading XM Arabia"""
    
    # GOLD (XAU/USD) sur XM Arabia:
    # Lundi 01:05 - Vendredi 23:50 (GMT+2)
    # Meilleure liquidite: London-NY overlap 13:00-17:00 GMT
    
    @staticmethod
    def get_current_session() -> TradingSession:
        """Determine la session de trading actuelle (GMT)"""
        now_utc = datetime.now(timezone.utc)
        hour = now_utc.hour
        weekday = now_utc.weekday()  # 0=Lundi, 6=Dimanche
        
        # Weekend = marche ferme
        if weekday == 5:  # Samedi
            return TradingSession.CLOSED
        elif weekday == 6:  # Dimanche
            if hour < 23:  # Ouverture a ~23:00 GMT (dimanche soir)
                return TradingSession.CLOSED
        elif weekday == 0 and hour < 1:  # Lundi avant 01:00 GMT
            return TradingSession.CLOSED
        
        # Sessions de trading
        if 0 <= hour < 9:
            return TradingSession.ASIAN
        elif 8 <= hour < 13:
            return TradingSession.EUROPEAN
        elif 13 <= hour < 17:
            return TradingSession.OVERLAP_EU_US  # Meilleure liquidite!
        elif 17 <= hour < 22:
            return TradingSession.AMERICAN
        elif 22 <= hour < 24:
            return TradingSession.AMERICAN  # Session US tardive
        
        return TradingSession.CLOSED
    
    @staticmethod
    def is_xm_market_open() -> bool:
        """Verifie si le marche GOLD est ouvert sur XM"""
        now_utc = datetime.now(timezone.utc)
        weekday = now_utc.weekday()
        hour = now_utc.hour
        minute = now_utc.minute
        
        # Samedi = toujours ferme
        if weekday == 5:
            return False
        
        # Dimanche = ouvre a 23:05 GMT
        if weekday == 6:
            return hour >= 23
        
        # Vendredi = ferme a 21:50 GMT (23:50 GMT+2)
        if weekday == 4:
            if hour > 21 or (hour == 21 and minute >= 50):
                return False
        
        # Lundi = ouvre a 23:05 GMT dimanche soir (01:05 GMT+2 lundi)
        # Donc deja couvert par le check dimanche
        
        return True
    
    @staticmethod
    def get_xm_server_time() -> str:
        """Retourne l'heure serveur XM (GMT+2)"""
        now_utc = datetime.now(timezone.utc)
        xm_time = now_utc + timedelta(hours=CONFIG["xm_gmt_offset"])
        return xm_time.strftime("%Y-%m-%d %H:%M:%S")
    
    @staticmethod
    def should_analyze(session: TradingSession) -> bool:
        """Determine si on doit analyser selon la configuration"""
        if session == TradingSession.CLOSED:
            return False
        if session == TradingSession.ASIAN and not CONFIG["analyze_asian"]:
            return False
        if session == TradingSession.EUROPEAN and not CONFIG["analyze_european"]:
            return False
        if session == TradingSession.AMERICAN and not CONFIG["analyze_american"]:
            return False
        if session == TradingSession.OVERLAP_EU_US:
            # Toujours analyser l'overlap (meilleure liquidite)
            return True
        if CONFIG["only_overlap_sessions"] and session != TradingSession.OVERLAP_EU_US:
            return False
        return True
    
    @staticmethod
    def get_next_session_info() -> str:
        """Retourne des informations sur la prochaine session"""
        now_utc = datetime.now(timezone.utc)
        session = XMMarketHours.get_current_session()
        
        if session == TradingSession.CLOSED:
            # Calculer quand le marche ouvre
            weekday = now_utc.weekday()
            if weekday == 5:  # Samedi
                days_until_open = 1  # Dimanche soir
            else:
                days_until_open = 0
            
            next_open = now_utc + timedelta(days=days_until_open)
            next_open = next_open.replace(hour=23, minute=5, second=0)
            hours_until = int((next_open - now_utc).total_seconds() / 3600)
            return f"Marche ferme - Ouverture dans ~{hours_until}h (Dimanche 23:05 GMT)"
        
        return f"Session active: {session.value}"

# ============================================================================
# GENERATION DU RAPPORT
# ============================================================================

class ReportGenerator:
    """Generation des rapports d'analyse"""
    
    @staticmethod
    def generate_full_report(df: pd.DataFrame, setups: List[TradingSetup]) -> AnalysisReport:
        """Genere un rapport d'analyse complet"""
        closes = df['Close']
        current_price = float(closes.iloc[-1])
        prev_close = float(closes.iloc[-2]) if len(closes) > 1 else current_price
        
        daily_change = current_price - prev_close
        daily_change_pct = (daily_change / prev_close) * 100
        
        # Indicateurs
        rsi = TechnicalIndicators.rsi(closes)
        macd_val, macd_sig, macd_hist = TechnicalIndicators.macd(closes)
        bb_upper, bb_mid, bb_lower = TechnicalIndicators.bollinger_bands(closes)
        atr = TechnicalIndicators.atr(df)
        ema20 = TechnicalIndicators.ema(closes, 20)
        ema50 = TechnicalIndicators.ema(closes, 50)
        ema200 = TechnicalIndicators.ema(closes, 200)
        stoch_k, stoch_d = TechnicalIndicators.stochastic(df)
        cci = TechnicalIndicators.cci(df)
        williams = TechnicalIndicators.williams_r(df)
        
        # Trend
        trend = SignalType.NEUTRAL
        trend_strength = 0
        trend_ema = "NEUTRAL"
        
        if current_price > ema20 and ema20 > ema50:
            trend = SignalType.BULLISH
            trend_ema = "BULLISH"
            trend_strength = min(100, 50 + (rsi - 50) * 0.5 + abs(macd_hist) * 10)
        elif current_price < ema20 and ema20 < ema50:
            trend = SignalType.BEARISH
            trend_ema = "BEARISH"
            trend_strength = min(100, 50 + (50 - rsi) * 0.5 + abs(macd_hist) * 10)
        
        # Niveaux cles
        highs_50 = df['High'].tail(50)
        lows_50 = df['Low'].tail(50)
        support = sorted(lows_50.nsmallest(5).values)
        resistance = sorted(highs_50.nlargest(5).values)
        
        # Session
        session = XMMarketHours.get_current_session()
        is_open = XMMarketHours.is_xm_market_open()
        xm_time = XMMarketHours.get_xm_server_time()
        
        # Recommandation
        recommendation, risk_level = ReportGenerator._generate_recommendation(
            trend, rsi, macd_hist, setups
        )
        
        # Prevision 24h
        forecast = ReportGenerator._generate_forecast(
            trend, rsi, macd_val, macd_hist, ema20, ema50, bb_upper, bb_lower
        )
        
        return AnalysisReport(
            id=f"report-{int(time.time())}",
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            current_price=round(current_price, 2),
            daily_change=round(daily_change, 2),
            daily_change_percent=round(daily_change_pct, 2),
            trend=trend.value,
            trend_strength=round(trend_strength, 1),
            trend_direction_ema=trend_ema,
            setups=setups,
            rsi=round(rsi, 1),
            rsi_status="Overbought" if rsi > 70 else "Oversold" if rsi < 30 else "Neutral",
            macd=round(macd_val, 4),
            macd_signal=round(macd_sig, 4),
            macd_histogram=round(macd_hist, 4),
            macd_status="Bullish" if macd_hist > 0 else "Bearish",
            ema_20=round(ema20, 2),
            ema_50=round(ema50, 2),
            ema_200=round(ema200, 2),
            bb_upper=round(bb_upper, 2),
            bb_middle=round(bb_mid, 2),
            bb_lower=round(bb_lower, 2),
            atr=round(atr, 2),
            stochastic_k=round(stoch_k, 1),
            stochastic_d=round(stoch_d, 1),
            stochastic_status="Overbought" if stoch_k > 80 else "Oversold" if stoch_k < 20 else "Neutral",
            cci=round(cci, 1),
            williams_r=round(williams, 1),
            support_levels=[round(s, 2) for s in support],
            resistance_levels=[round(r, 2) for r in resistance],
            recommendation=recommendation,
            risk_level=risk_level,
            forecast_24h=forecast,
            session=session.value,
            is_xm_market_open=is_open,
            xm_server_time=xm_time,
            next_analysis_in=CONFIG["check_interval_minutes"]
        )
    
    @staticmethod
    def _generate_recommendation(trend, rsi, macd_hist, setups) -> Tuple[str, str]:
        """Genere une recommandation de trading"""
        bullish_setups = [s for s in setups if s.direction == "bullish"]
        bearish_setups = [s for s in setups if s.direction == "bearish"]
        
        if bullish_setups and trend == SignalType.BULLISH:
            best = max(bullish_setups, key=lambda x: x.confidence)
            return (
                f"SIGNAL D'ACHAT FORT - {len(bullish_setups)} setup(s) haussier(s) detecte(s). "
                f"Meilleur setup: {best.type} avec {best.confidence}% de confiance. "
                f"Entry: ${best.entry_price}, SL: ${best.stop_loss}, TP1: ${best.take_profit_1}, "
                f"TP2: ${best.take_profit_2}, TP3: ${best.take_profit_3}. Ratio R/R: {best.risk_reward_ratio}.",
                "low" if best.confidence >= 80 else "medium"
            )
        
        elif bearish_setups and trend == SignalType.BEARISH:
            best = max(bearish_setups, key=lambda x: x.confidence)
            return (
                f"SIGNAL DE VENTE FORT - {len(bearish_setups)} setup(s) baissier(s) detecte(s). "
                f"Meilleur setup: {best.type} avec {best.confidence}% de confiance. "
                f"Entry: ${best.entry_price}, SL: ${best.stop_loss}, TP1: ${best.take_profit_1}, "
                f"TP2: ${best.take_profit_2}, TP3: ${best.take_profit_3}. Ratio R/R: {best.risk_reward_ratio}.",
                "low" if best.confidence >= 80 else "medium"
            )
        
        elif not setups:
            return (
                f"AUCUN SIGNAL CLAIR - Le marche est en consolidation. "
                f"RSI a {rsi:.1f} ({'surachat' if rsi > 70 else 'survente' if rsi < 30 else 'neutre'}). "
                f"Attendre un setup clair avant d'entrer en position.",
                "medium"
            )
        
        else:
            return (
                f"SIGNAUX MIXTES - {len(bullish_setups)} haussier(s) vs {len(bearish_setups)} baissier(s). "
                f"Attendre une confirmation avant de trader. Tendance: {trend.value}.",
                "high"
            )
    
    @staticmethod
    def _generate_forecast(trend, rsi, macd, macd_hist, ema20, ema50, bb_upper, bb_lower) -> str:
        """Genere une prevision 24h"""
        if trend == SignalType.BULLISH:
            forecast = f"Tendance haussiere confirmee. "
            if rsi > 70:
                forecast += f"RSI en surachat ({rsi:.1f}), attention a une correction possible vers ${(ema20 * 0.995):.2f}. "
            else:
                forecast += f"Momentum positif. "
            targets = f"Objectifs: ${(ema20 * 1.005):.2f} / ${(ema20 * 1.01):.2f} / ${(ema20 * 1.015):.2f}."
        elif trend == SignalType.BEARISH:
            forecast = f"Tendance baissiere confirmee. "
            if rsi < 30:
                forecast += f"RSI en survente ({rsi:.1f}), rebond possible vers ${(ema20 * 1.005):.2f}. "
            else:
                forecast += f"Momentum negatif. "
            targets = f"Objectifs: ${(ema20 * 0.995):.2f} / ${(ema20 * 0.99):.2f} / ${(ema20 * 0.985):.2f}."
        else:
            forecast = f"Marche sans tendance (range). "
            targets = f"Support: ${bb_lower:.2f} | Resistance: ${bb_upper:.2f}. Attendre un breakout."
        
        if macd_hist > 0:
            forecast += f" MACD haussier confirme."
        elif macd_hist < 0:
            forecast += f" MACD baissier confirme."
        
        return forecast + " " + targets

# ============================================================================
# ENVOI D'EMAIL
# ============================================================================

class EmailSender:
    """Envoi de rapports par email"""
    
    @staticmethod
    def send_report(report: AnalysisReport) -> bool:
        """Envoie le rapport par email"""
        if not all([CONFIG["smtp_username"], CONFIG["smtp_password"], CONFIG["recipient_email"]]):
            logger.warning("Configuration email incomplete - rapport non envoye")
            return False
        
        try:
            html_content = EmailSender._generate_html_email(report)
            
            msg = MIMEMultipart('alternative')
            msg['Subject'] = f"XAUUSD ALERT - {len(report.setups)} Setup(s) | ${report.current_price} | {report.timestamp}"
            msg['From'] = CONFIG["smtp_username"]
            msg['To'] = CONFIG["recipient_email"]
            
            msg.attach(MIMEText(html_content, 'html', 'utf-8'))
            
            context = ssl.create_default_context()
            
            with smtplib.SMTP(CONFIG["smtp_host"], CONFIG["smtp_port"]) as server:
                server.starttls(context=context)
                server.login(CONFIG["smtp_username"], CONFIG["smtp_password"])
                server.sendmail(
                    CONFIG["smtp_username"],
                    CONFIG["recipient_email"],
                    msg.as_string()
                )
            
            logger.info(f"Email envoye avec succes a {CONFIG['recipient_email']}")
            return True
            
        except Exception as e:
            logger.error(f"Erreur envoi email: {e}")
            return False
    
    @staticmethod
    def _generate_html_email(report: AnalysisReport) -> str:
        """Genere le contenu HTML de l'email"""
        
        setups_html = ""
        for setup in report.setups:
            direction_color = "#48bb78" if setup.direction == "bullish" else "#f56565"
            setups_html += f"""
            <div style="border: 1px solid {direction_color}; padding: 15px; margin: 10px 0; border-radius: 8px; background: #1a202c;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                    <span style="color: {direction_color}; font-weight: bold; font-size: 16px;">{setup.direction.upper()} - {setup.type.upper()}</span>
                    <span style="color: #ffd700; font-weight: bold;">{setup.confidence}% Confiance</span>
                </div>
                <p style="color: #e0e6ed; margin: 5px 0;">{setup.description}</p>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px;">
                    <div><span style="color: #a0aec0; font-size: 12px;">Entry:</span> <span style="color: #ffd700; font-weight: bold;">${setup.entry_price}</span></div>
                    <div><span style="color: #a0aec0; font-size: 12px;">SL:</span> <span style="color: #f56565; font-weight: bold;">${setup.stop_loss}</span></div>
                    <div><span style="color: #a0aec0; font-size: 12px;">TP1:</span> <span style="color: #48bb78; font-weight: bold;">${setup.take_profit_1}</span></div>
                    <div><span style="color: #a0aec0; font-size: 12px;">TP2:</span> <span style="color: #48bb78; font-weight: bold;">${setup.take_profit_2}</span></div>
                    <div><span style="color: #a0aec0; font-size: 12px;">TP3:</span> <span style="color: #48bb78; font-weight: bold;">${setup.take_profit_3}</span></div>
                    <div><span style="color: #a0aec0; font-size: 12px;">R/R:</span> <span style="color: #63b3ed; font-weight: bold;">{setup.risk_reward_ratio}</span></div>
                </div>
            </div>
            """
        
        trend_color = "#48bb78" if report.trend == "bullish" else "#f56565" if report.trend == "bearish" else "#ed8936"
        risk_color = {"low": "#48bb78", "medium": "#ed8936", "high": "#f56565"}[report.risk_level]
        
        return f"""
        <!DOCTYPE html>
        <html>
        <head><meta charset="UTF-8"></head>
        <body style="font-family: Arial, sans-serif; background: #0a0e1a; color: #e0e6ed; margin: 0; padding: 20px;">
            <div style="max-width: 600px; margin: 0 auto;">
                <div style="background: linear-gradient(135deg, #1a1f2e, #2d3748); padding: 30px; border-radius: 16px; border: 1px solid #4a5568; margin-bottom: 20px;">
                    <h1 style="color: #ffd700; margin: 0; font-size: 28px;">XAUUSD Trading Alert</h1>
                    <p style="color: #a0aec0; margin: 5px 0 0 0;">{report.timestamp} | XM Arabia Server Time: {report.xm_server_time}</p>
                </div>
                
                <div style="background: #1a202c; padding: 25px; border-radius: 12px; border: 1px solid #4a5568; margin-bottom: 20px;">
                    <h2 style="color: #ffd700; margin: 0 0 10px 0; font-size: 36px;">${report.current_price}</h2>
                    <p style="color: {'#48bb78' if report.daily_change >= 0 else '#f56565'}; font-size: 18px; margin: 0;">
                        {'+' if report.daily_change >= 0 else ''}{report.daily_change} ({'+' if report.daily_change_percent >= 0 else ''}{report.daily_change_percent}%)
                    </p>
                    <div style="margin-top: 15px;">
                        <span style="color: #a0aec0;">Tendance: </span>
                        <span style="color: {trend_color}; font-weight: bold;">{report.trend.upper()}</span>
                        <span style="color: #a0aec0; margin-left: 20px;">Force: </span>
                        <span style="color: #ffd700; font-weight: bold;">{report.trend_strength}%</span>
                    </div>
                </div>
                
                <div style="background: #1a202c; padding: 20px; border-radius: 12px; border: 1px solid #4a5568; margin-bottom: 20px;">
                    <h3 style="color: #ffd700; margin: 0 0 15px 0;">Indicateurs Techniques</h3>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 14px;">
                        <div><span style="color: #a0aec0;">RSI (14):</span> <span style="color: {'#f56565' if report.rsi > 70 else '#48bb78' if report.rsi < 30 else '#e0e6ed'}; font-weight: bold;">{report.rsi} ({report.rsi_status})</span></div>
                        <div><span style="color: #a0aec0;">MACD:</span> <span style="color: {'#48bb78' if report.macd_histogram > 0 else '#f56565'}; font-weight: bold;">{report.macd_status}</span></div>
                        <div><span style="color: #a0aec0;">EMA 20:</span> <span style="color: #e0e6ed;">${report.ema_20}</span></div>
                        <div><span style="color: #a0aec0;">EMA 50:</span> <span style="color: #e0e6ed;">${report.ema_50}</span></div>
                        <div><span style="color: #a0aec0;">BB Upper:</span> <span style="color: #f56565;">${report.bb_upper}</span></div>
                        <div><span style="color: #a0aec0;">BB Lower:</span> <span style="color: #48bb78;">${report.bb_lower}</span></div>
                        <div><span style="color: #a0aec0;">ATR (14):</span> <span style="color: #e0e6ed;">${report.atr}</span></div>
                        <div><span style="color: #a0aec0;">Stoch %K:</span> <span style="color: #e0e6ed;">{report.stochastic_k}</span></div>
                    </div>
                </div>
                
                {f'<h3 style="color: #ffd700; font-size: 20px;">Setups Detectes ({len(report.setups)})</h3>' + setups_html if report.setups else '<div style="background: #1a202c; padding: 20px; border-radius: 12px; text-align: center; color: #a0aec0;">Aucun setup detecte pour le moment.</div>'}
                
                <div style="background: #1a202c; padding: 20px; border-radius: 12px; border: 2px solid {risk_color}; margin-top: 20px;">
                    <h3 style="color: {risk_color}; margin: 0 0 10px 0;">Recommandation - Risque: {report.risk_level.upper()}</h3>
                    <p style="color: #e0e6ed; line-height: 1.6; margin: 0;">{report.recommendation}</p>
                </div>
                
                <div style="background: #1a202c; padding: 20px; border-radius: 12px; border: 1px solid #63b3ed; margin-top: 20px;">
                    <h3 style="color: #63b3ed; margin: 0 0 10px 0;">Prevision 24H</h3>
                    <p style="color: #e0e6ed; line-height: 1.6; margin: 0;">{report.forecast_24h}</p>
                </div>
                
                <div style="text-align: center; padding: 20px; color: #4a5568; margin-top: 20px; border-top: 1px solid #2d3748;">
                    <p>XAUUSD 24/7 Analyzer | XM Arabia Edition | Signal automatique</p>
                    <p style="font-size: 12px;">Ce rapport est genere automatiquement a titre informatif. Le trading comporte des risques.</p>
                </div>
            </div>
        </body>
        </html>
        """

# ============================================================================
# SAUVEGARDE DES RAPPORTS
# ============================================================================

class ReportSaver:
    """Sauvegarde des rapports"""
    
    @staticmethod
    def save_report(report: AnalysisReport):
        """Sauvegarde le rapport en JSON"""
        if not CONFIG["save_reports"]:
            return
        
        try:
            os.makedirs(CONFIG["reports_directory"], exist_ok=True)
            
            filename = f"report_{report.id}.json"
            filepath = os.path.join(CONFIG["reports_directory"], filename)
            
            # Convertir dataclass en dict
            report_dict = asdict(report)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report_dict, f, indent=2, ensure_ascii=False)
            
            logger.debug(f"Rapport sauvegarde: {filepath}")
            
        except Exception as e:
            logger.error(f"Erreur sauvegarde rapport: {e}")

# ============================================================================
# AFFICHAGE CONSOLE
# ============================================================================

class ConsoleDisplay:
    """Affichage dans la console"""
    
    @staticmethod
    def display_banner():
        """Affiche la banniere de demarrage"""
        banner = """
        ╔══════════════════════════════════════════════════════════════════╗
        ║                                                                  ║
        ║           XAUUSD 24/7 TRADING ANALYZER                           ║
        ║              XM ARABIA EDITION                                   ║
        ║                                                                  ║
        ║   Broker: xmarabia.net | Gold Spot / US Dollar                   ║
        ║   Horaires: Lun 01:05 - Ven 23:50 (GMT+2)                      ║
        ║                                                                  ║
        ╚══════════════════════════════════════════════════════════════════╝
        """
        print(banner)
    
    @staticmethod
    def display_report(report: AnalysisReport):
        """Affiche le rapport dans la console"""
        print("\n" + "="*70)
        print(f"  RAPPORT XAU/USD | {report.timestamp}")
        print(f"  XM Server Time: {report.xm_server_time} | Session: {report.session.upper()}")
        print("="*70)
        
        # Prix
        trend_icon = "B" if report.trend == "bullish" else "S" if report.trend == "bearish" else "N"
        print(f"\n  [{trend_icon}] PRIX: ${report.current_price}", end="")
        change_color = "\033[92m" if report.daily_change >= 0 else "\033[91m"
        print(f"  {change_color}{'+' if report.daily_change >= 0 else ''}{report.daily_change} ({'+' if report.daily_change_percent >= 0 else ''}{report.daily_change_percent}%)\033[0m")
        print(f"      Tendance: {report.trend.upper()} | Force: {report.trend_strength}%")
        print(f"      Marche XM: {'\033[92mOUVERT\033[0m' if report.is_xm_market_open else '\033[91mFERME\033[0m'}")
        
        # Indicateurs
        print(f"\n  --- INDICATEURS ---")
        rsi_color = "\033[91m" if report.rsi > 70 or report.rsi < 30 else "\033[0m"
        macd_color = "\033[92m" if report.macd_histogram > 0 else "\033[91m"
        print(f"      RSI: {rsi_color}{report.rsi} ({report.rsi_status})\033[0m")
        print(f"      MACD: {macd_color}{report.macd_histogram:+.4f} ({report.macd_status})\033[0m")
        print(f"      EMA 20: ${report.ema_20} | EMA 50: ${report.ema_50} | EMA 200: ${report.ema_200}")
        print(f"      BB: ${report.bb_lower} / ${report.bb_middle} / ${report.bb_upper}")
        print(f"      ATR: ${report.atr} | Stoch K: {report.stochastic_k}")
        
        # Setups
        print(f"\n  --- SETUPS ({len(report.setups)}) ---")
        for i, setup in enumerate(report.setups[:5], 1):
            direction_icon = "\033[92mBUY\033[0m" if setup.direction == "bullish" else "\033[91mSELL\033[0m"
            conf_color = "\033[92m" if setup.confidence >= 80 else "\033[93m" if setup.confidence >= 65 else "\033[91m"
            print(f"\n  [{i}] {direction_icon} {setup.type.upper()} | {setup.timeframe}")
            print(f"      Confiance: {conf_color}{setup.confidence}%\033[0m | R/R: {setup.risk_reward_ratio}")
            print(f"      Entry: ${setup.entry_price} | SL: ${setup.stop_loss}")
            print(f"      TP1: ${setup.take_profit_1} | TP2: ${setup.take_profit_2} | TP3: ${setup.take_profit_3}")
            print(f"      {setup.description}")
        
        # Recommandation
        print(f"\n  --- RECOMMANDATION ---")
        risk_color = "\033[92m" if report.risk_level == "low" else "\033[93m" if report.risk_level == "medium" else "\033[91m"
        print(f"      Risque: {risk_color}{report.risk_level.upper()}\033[0m")
        print(f"      {report.recommendation}")
        
        # Prevision
        print(f"\n  --- PREVISION 24H ---")
        print(f"      {report.forecast_24h}")
        
        print(f"\n  Prochaine analyse dans {report.next_analysis_in} minutes...")
        print("="*70)

# ============================================================================
# ANALYZER PRINCIPAL
# ============================================================================

class XAUUSDAnalyzer:
    """Analyseur principal XAU/USD"""
    
    def __init__(self):
        self.running = False
        self.setup_count_history = []
        
    def start(self):
        """Demarre l'analyse 24/7"""
        self.running = True
        ConsoleDisplay.display_banner()
        
        # Verifier la configuration email
        if not CONFIG["smtp_username"]:
            logger.warning("⚠ Email non configure - Les rapports ne seront pas envoyes")
            logger.info("Editez le fichier et renseignez: smtp_username, smtp_password, recipient_email")
        
        logger.info("🚀 Demarrage de l'analyse XAU/USD 24/7...")
        logger.info(f"⏱ Intervalle: {CONFIG['check_interval_minutes']} minutes")
        logger.info(f"📊 Confiance minimum: {CONFIG['min_confidence']}%")
        logger.info(f"📧 Email: {'Active' if CONFIG['smtp_username'] else 'Non configure'}")
        
        # Premier cycle immediat
        self._run_analysis_cycle()
        
        # Boucle principale
        while self.running:
            try:
                time.sleep(CONFIG["check_interval_minutes"] * 60)
                if self.running:
                    self._run_analysis_cycle()
            except KeyboardInterrupt:
                logger.info("\n🛑 Arret demande par l'utilisateur...")
                self.stop()
                break
            except Exception as e:
                logger.error(f"Erreur dans la boucle principale: {e}")
                time.sleep(60)  # Attendre 1 min avant retry
    
    def _run_analysis_cycle(self):
        """Execute un cycle d'analyse complet"""
        logger.info("\n" + "="*50)
        logger.info("📊 NOUVELLE ANALYSE EN COURS...")
        logger.info("="*50)
        
        # 1. Verifier l'etat du marche XM
        is_open = XMMarketHours.is_xm_market_open()
        session = XMMarketHours.get_current_session()
        xm_time = XMMarketHours.get_xm_server_time()
        
        logger.info(f"🕐 XM Server Time: {xm_time}")
        logger.info(f"📍 Session: {session.value}")
        logger.info(f"🏪 Marche XM: {'OUVERT' if is_open else 'FERME'}")
        
        if not is_open:
            logger.info("💤 Marche ferme - Analyse reportee")
            next_info = XMMarketHours.get_next_session_info()
            logger.info(f"⏰ {next_info}")
            return
        
        if not XMMarketHours.should_analyze(session):
            logger.info(f"💤 Session {session.value} desactivee dans la configuration")
            return
        
        # 2. Recuperer les donnees
        logger.info("📥 Recuperation des donnees de marche...")
        data = MarketDataManager.fetch_multi_timeframe()
        
        if not data:
            logger.error("❌ Impossible de recuperer les donnees")
            return
        
        # 3. Detecter les setups sur chaque timeframe
        logger.info("🔍 Detection des setups de trading...")
        all_setups = []
        
        priority_timeframes = ["H1", "H4", "D1"]
        
        for tf in priority_timeframes:
            if tf in data:
                logger.debug(f"  Analyse {tf}...")
                setups = SetupDetector.detect_all_setups(data[tf], tf, session.value)
                all_setups.extend(setups)
        
        # 4. Filtrer et trier les setups
        all_setups = sorted(all_setups, key=lambda x: x.confidence, reverse=True)
        
        if all_setups:
            logger.info(f"✅ {len(all_setups)} setup(s) detecte(s)!")
            for s in all_setups[:3]:
                icon = "🟢" if s.direction == "bullish" else "🔴"
                logger.info(f"   {icon} {s.type.upper()} {s.direction.upper()} | {s.timeframe} | {s.confidence}% | ${s.entry_price}")
        else:
            logger.info("⚪ Aucun setup detecte")
        
        # 5. Generer le rapport (utilise H1 comme reference)
        primary_data = data.get("H1", list(data.values())[0])
        report = ReportGenerator.generate_full_report(primary_data, all_setups)
        
        # 6. Afficher dans la console
        ConsoleDisplay.display_report(report)
        
        # 7. Sauvegarder le rapport
        ReportSaver.save_report(report)
        
        # 8. Envoyer par email si des setups sont detectes
        if all_setups and CONFIG["smtp_username"]:
            logger.info("📧 Envoi du rapport par email...")
            success = EmailSender.send_report(report)
            if success:
                logger.info("✅ Email envoye avec succes!")
            else:
                logger.error("❌ Echec de l'envoi d'email")
        
        logger.info("✅ Cycle d'analyse termine")
    
    def stop(self):
        """Arrete l'analyseur"""
        self.running = False
        logger.info("👋 Analyseur arrete. A bientot!")


# ============================================================================
# GESTION DU SIGNAL D'ARRET
# ============================================================================

def signal_handler(sig, frame):
    """Gestion du Ctrl+C"""
    print("\n")
    logger.info("🛑 Signal d'arret recu (Ctrl+C)")
    if 'analyzer' in globals():
        analyzer.stop()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)


# ============================================================================
# POINT D'ENTREE
# ============================================================================

if __name__ == "__main__":
    analyzer = XAUUSDAnalyzer()
    analyzer.start()

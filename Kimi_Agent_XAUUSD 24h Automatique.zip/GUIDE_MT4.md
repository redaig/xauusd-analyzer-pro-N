# Guide MT4 - Synchronisation XAUUSD

## Etape 1: Copier le fichier EA dans MT4

1. Ouvre MT4
2. Va dans **Fichier > Ouvrir le dossier de donnees** (Ctrl+Shift+D)
3. Navigue vers: `MQL4/Experts/`
4. Copie le fichier `MT4_XAUUSD_Sync.mq4` dans ce dossier

## Etape 2: Compiler l'EA

1. Dans MT4, appuie sur **F4** pour ouvrir l'editeur MetaEditor
2. Trouve `MT4_XAUUSD_Sync` dans la liste des Experts
3. Double-clique pour l'ouvrir
4. Appuie sur **F7** pour compiler
5. Ferme MetaEditor

## Etape 3: Attacher au graphique XAUUSD

1. Dans le **Navigateur** MT4 (Ctrl+N), va dans **Experts**
2. Trouve `MT4_XAUUSD_Sync`
3. Fais-le glisser sur le graphique **XAUUSD, M15** (ou H1)
4. Coche **Autoriser le trading automatique** (meme si l'EA ne trade pas)
5. Clique sur **OK**

## Etape 4: Lire les prix

Les prix s'affichent maintenant dans les **commentaires** du graphique:

```
========================================
   XAUUSD - PRIX MT4 (XM ARABIA)
========================================

PRIX ACTUEL:
  Bid:  4717.31
  Ask:  4717.78
  Spread: 0.47

TENDANCE H4: HAUSSIERE
  EMA20: 4712.50
  EMA50: 4708.20
  EMA200: 4680.15

INDICATEURS:
  RSI(14): 58.3
  MACD: 0.0025
  Signal: 0.0018
  ATR(14): 4.62

--- COPIE LE PRIX DANS LE SITE ---
Prix a copier: 4717.31
========================================
```

## Etape 5: Copier dans le site

1. Lis le **Prix a copier** dans MT4 (ex: `4717.31`)
2. Va sur le site: https://46yg6z5oiyrce.kimi.page
3. Colle le prix dans le champ **"Prix XM"**
4. Clique sur **Actualiser**

## Alternative: Script simple (sans compilation)

Si la compilation ne marche pas, utilise un **Script** a la place:

### Methode simple - Script MQL4

1. Dans MetaEditor (F4), cree un nouveau fichier: **Nouveau > Script**
2. Copie ce code:

```mql4
#property strict
#property script_show_inputs

void OnStart()
{
   double bid = Bid;
   double ask = Ask;
   double ema20 = iMA(Symbol(), PERIOD_H1, 20, 0, MODE_EMA, PRICE_CLOSE, 0);
   double ema50 = iMA(Symbol(), PERIOD_H1, 50, 0, MODE_EMA, PRICE_CLOSE, 0);
   
   string msg = "Prix XAUUSD MT4:\n";
   msg += "Bid: " + DoubleToString(bid, 2) + "\n";
   msg += "Ask: " + DoubleToString(ask, 2) + "\n";
   msg += "EMA20: " + DoubleToString(ema20, 2) + "\n";
   msg += "EMA50: " + DoubleToString(ema50, 2) + "\n";
   msg += "\nCopie Bid dans le site!";
   
   MessageBox(msg, "XAUUSD Prix MT4");
   
   // Copie dans le presse-papiers
   if(CopyToClipboard(DoubleToString(bid, 2)))
      Print("Prix copie dans le presse-papiers!");
}
```

3. Sauvegarde (Ctrl+S)
4. Compile avec F7
5. Va dans MT4, **Navigateur > Scripts**
6. Glisse le script sur le graphique XAUUSD
7. Le prix s'affiche dans une boite de dialogue

## FAQ

**Q: Est-ce que l'EA trade automatiquement?**
R: NON. L'EA ne fait qu'afficher les prix et les indicateurs. Aucun ordre n'est passe.

**Q: Pourquoi le prix MT4 est different de TradingView?**
R: XM Arabia ajoute un spread/markup de 1-3$ par rapport au prix interbancaire. C'est normal et c'est comme ca que le broker gagne de l'argent.

**Q: Combien de temps l'EA tourne?**
R: Tant que MT4 est ouvert et que le graphique est actif. Si tu fermes MT4, l'EA s'arrete.

**Q: Est-ce que je peux avoir plusieurs graphiques XAUUSD?**
R: Oui, mais attache l'EA uniquement sur UN seul graphique XAUUSD pour eviter les conflits.

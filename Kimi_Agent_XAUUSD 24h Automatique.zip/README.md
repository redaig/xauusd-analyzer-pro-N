# XAUUSD 24/7 Trading Analyzer - XM Arabia Edition

Analyse technique complete de l'or (XAU/USD) avec detection automatique de setups haute qualite et envoi de rapports par email.

**Broker:** XM Arabia (xmarabia.net)
**Horaires GOLD:** Lundi 01:05 - Vendredi 23:50 (GMT+2)

---

## Installation

### 1. Installer Python

Telechargez et installez Python 3.10+ :
- Windows: https://python.org/downloads
- Cochez **"Add Python to PATH"** pendant l'installation

### 2. Telecharger le programme

Placez ces 3 fichiers dans un dossier:
```
mon_dossier/
  xauusd_analyzer.py   (le programme principal)
  config.json          (votre configuration)
  requirements.txt     (dependances)
```

### 3. Installer les dependances

Ouvrez un terminal (CMD sur Windows) dans le dossier:
```bash
pip install -r requirements.txt
```

---

## Configuration Email (OBLIGATOIRE pour les alertes)

### Gmail (Recommande)

#### Etape 1: Activer la verification en 2 etapes
```
→ https://myaccount.google.com/security
→ "Verification en deux etapes" → Activer
```

#### Etape 2: Creer un mot de passe d'application
```
→ https://myaccount.google.com/apppasswords
→ Selectionnez "Mail" dans le menu
→ Selectionnez "Autre (nom personnalise)"
→ Tapez: XAUUSD Analyzer
→ Cliquez "Generer"
→ Copiez le code de 16 caracteres (ex: abcd efgh ijkl mnop)
```

#### Etape 3: Modifier config.json

Ouvrez `config.json` avec un editeur de texte (Notepad):

```json
{
  "smtp_host": "smtp.gmail.com",
  "smtp_port": 587,
  "smtp_username": "VOTRE_EMAIL@gmail.com",
  "smtp_password": "xxxx xxxx xxxx xxxx",
  "recipient_email": "EMAIL_QUI_RECOIT@gmail.com",
  ...
}
```

### Outlook/Hotmail
```json
{
  "smtp_host": "smtp.office365.com",
  "smtp_port": 587,
  "smtp_username": "votre@outlook.com",
  "smtp_password": "votre_mot_de_passe_app",
  "recipient_email": "votre@outlook.com"
}
```

### Yahoo Mail
```json
{
  "smtp_host": "smtp.mail.yahoo.com",
  "smtp_port": 587,
  "smtp_username": "votre@yahoo.com",
  "smtp_password": "votre_mot_de_passe_app",
  "recipient_email": "votre@yahoo.com"
}
```

---

## Lancer le programme

### Windows
```bash
python xauusd_analyzer.py
```

### Pour le garder ouvert 24/7

#### Option 1: Laisser le CMD ouvert (simple)
Juste lancez la commande et laissez la fenetre ouverte.

#### Option 2: Executer en arriere-plan (recommande)
1. Creez un fichier `start.bat`:
```batch
@echo off
cd /d "C:\chemin\vers\le\dossier"
python xauusd_analyzer.py
```

2. Double-cliquez sur `start.bat`

#### Option 3: Tache planifiee Windows (vrai 24/7)
1. Ouvrez le Planificateur de taches
2. Creez une tache qui demarre au boot
3. Action: lancer `python.exe` avec argument `xauusd_analyzer.py`

---

## Personnalisation (config.json)

| Parametre | Description | Defaut |
|-----------|-------------|--------|
| `min_confidence` | Confiance minimum (%) pour signaler un setup | 65 |
| `check_interval_minutes` | Minutes entre chaque analyse | 5 |
| `analyze_asian` | Analyser session asiatique | true |
| `analyze_european` | Analyser session europeenne | true |
| `analyze_american` | Analyser session americaine | true |
| `only_overlap_sessions` | Uniquement overlap EU/US (meilleure liquidite) | false |
| `atr_multiplier_sl` | Multiplicateur ATR pour Stop Loss | 2.0 |
| `atr_multiplier_tp1` | Multiplicateur ATR pour TP1 | 2.5 |
| `atr_multiplier_tp2` | Multiplicateur ATR pour TP2 | 4.0 |
| `atr_multiplier_tp3` | Multiplicateur ATR pour TP3 | 6.0 |

---

## Ce que le programme fait

### Analyse 24/7 automatique:
- Recupere les donnees XAU/USD en temps reel (Yahoo Finance)
- Analyse sur 5 timeframes: M5, M15, H1, H4, D1
- Detecte 6 types de setups: Breakout, Reversal, Trend, Range, Divergence
- Calcule 10+ indicateurs: RSI, MACD, BB, EMA, ATR, Stochastic, CCI
- Respecte les horaires XM Arabia (ferme weekend)
- Filtre par session (Asie, Europe, US)

### Envoi automatique d'emails:
- Email envoye a CHAQUE setup detecte
- Rapport HTML professionnel avec:
  - Prix actuel + variation 24h
  - Tous les indicateurs techniques
  - Setups avec Entry/SL/TP1/TP2/TP3
  - Ratio Risk/Reward
  - Niveaux Support/Resistance
  - Recommandation et prevision 24h

### Detection de setups haute qualite:

**Setup Type 1 - RSI Reversal (Winrate ~75%)**
- RSI en survente (<30) + confirmation EMA = ACHAT
- RSI en surachat (>70) + confirmation EMA = VENTE

**Setup Type 2 - MACD Trend (Winrate ~70%)**
- MACD croisement haussier + prix > EMA50 = ACHAT
- MACD croisement baissier + prix < EMA50 = VENTE

**Setup Type 3 - Bollinger Bands (Winrate ~72%)**
- Prix sous bande inferieure + RSI faible = ACHAT
- Prix au-dessus bande superieure + RSI eleve = VENTE

**Setup Type 4 - EMA Cross (Winrate ~78%)**
- Golden Cross (EMA20>EMA50) + Prix>EMA200 = ACHAT FORT
- Death Cross (EMA20<EMA50) + Prix<EMA200 = VENTE FORTE

**Setup Type 5 - Breakout S/R (Winrate ~65%)**
- Breakout resistance + volume confirme = ACHAT
- Breakdown support + volume confirme = VENTE

**Setup Type 6 - Stochastic (Winrate ~68%)**
- Stochastic croisement haussier en survente = ACHAT
- Stochastic croisement baissier en surachat = VENTE

---

## Sessions de Trading (Horaires GMT)

| Session | Horaires GMT | Liquidite |
|---------|-------------|-----------|
| Asiatique | 00:00 - 09:00 | Faible |
| Europeenne | 08:00 - 17:00 | Moyenne |
| **Overlap EU/US** | **13:00 - 17:00** | **EXCELLENTE** |
| Americaine | 13:00 - 22:00 | Forte |

**Conseil:** Les meilleurs setups se forment pendant l'overlap Londres-New York (13h-17h GMT).

---

## Horaires XM Arabia pour GOLD (XAU/USD)

| Jour | Ouverture | Fermeture |
|------|-----------|-----------|
| Lundi | 01:05 (GMT+2) | 23:55 |
| Mardi-Jeudi | 01:05 (GMT+2) | 23:55 |
| Vendredi | 01:05 (GMT+2) | 23:50 |
| Samedi | **FERME** | **FERME** |
| Dimanche | **FERME** | Ouverture 23:05 |

---

## Arreter le programme

Appuyez sur **Ctrl+C** dans le terminal.

---

## Fichiers generes

- `xauusd_analyzer.log` - Logs de l'analyseur
- `reports/report_*.json` - Rapports sauvegardes (si active)

---

## Support

Pour toute question ou probleme, verifiez:
1. Python est bien installe: `python --version`
2. Les dependances sont installees: `pip list | findstr yfinance`
3. Votre config.json est valide (JSON valide)
4. Votre mot de passe d'application est correct

**Disclaimer:** Ce programme est a titre informatif uniquement. Le trading comporte des risques. Ne tradez jamais plus que ce que vous pouvez perdre.

//+------------------------------------------------------------------+
//|                                      XAUUSD_Sync_Kimi.mq4        |
//|  Synchronise le prix XAUUSD de MT4 avec le systeme d'analyse     |
//|  Comment utiliser:                                               |
//|  1. Copier ce fichier dans MQL4/Experts/                         |
//|  2. Compiler (F7)                                                |
//|  3. Attacher au graphique XAUUSD (M15 ou H1)                     |
//|  4. Lire les prix dans les commentaires                          |
//+------------------------------------------------------------------+
#property copyright "Kimi XAUUSD System"
#property version   "1.00"
#property strict

input string   InpWebhookURL = "";  // URL Webhook (optionnel)
input int      InpRefreshMs  = 1000; // Rafraichissement (ms)
input bool     InpShowEMA    = true; // Afficher EMA20/50/200
input bool     InpShowRSI    = true; // Afficher RSI

// Variables globales
double g_bid, g_ask, g_spread;
datetime g_lastBar = 0;
int g_tickCount = 0;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   Comment("XAUUSD Sync - Chargement...");
   
   // Verifier qu'on est sur XAUUSD
   if(StringFind(Symbol(), "XAU") == -1 && StringFind(Symbol(), "GOLD") == -1)
   {
      Alert("ATTENTION: Cet EA doit etre place sur le graphique XAUUSD (or)");
   }
   
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   Comment("");
   Print("XAUUSD Sync arrete");
}

//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
   g_tickCount++;
   
   // Mettre a jour toutes les secondes (pas a chaque tick)
   static datetime lastUpdate = 0;
   if(TimeCurrent() - lastUpdate < InpRefreshMs / 1000) return;
   lastUpdate = TimeCurrent();
   
   // Prix actuels
   g_bid = Bid;
   g_ask = Ask;
   g_spread = (g_ask - g_bid) / Point / 10; // en points/pips
   
   // === CALCUL DES INDICATEURS ===
   double ema20 = iMA(Symbol(), 0, 20, 0, MODE_EMA, PRICE_CLOSE, 0);
   double ema50 = iMA(Symbol(), 0, 50, 0, MODE_EMA, PRICE_CLOSE, 0);
   double ema200 = iMA(Symbol(), 0, 200, 0, MODE_EMA, PRICE_CLOSE, 0);
   
   double rsi = iRSI(Symbol(), 0, 14, PRICE_CLOSE, 0);
   
   // MACD
   double macdMain = iMACD(Symbol(), 0, 12, 26, 9, PRICE_CLOSE, MODE_MAIN, 0);
   double macdSignal = iMACD(Symbol(), 0, 12, 26, 9, PRICE_CLOSE, MODE_SIGNAL, 0);
   
   // ATR
   double atr = iATR(Symbol(), 0, 14, 0);
   
   // Tendance
   string trend = "NEUTRE";
   color trendColor = clrYellow;
   if(ema20 > ema50 && ema50 > ema200) { trend = "HAUSSIERE"; trendColor = clrLime; }
   else if(ema20 < ema50 && ema50 < ema200) { trend = "BAISSIERE"; trendColor = clrRed; }
   
   // === AFFICHAGE DANS LES COMMENTAIRES ===
   string comment = "";
   
   comment += "========================================\n";
   comment += "   XAUUSD - PRIX MT4 (XM ARABIA)\n";
   comment += "========================================\n\n";
   
   comment += "PRIX ACTUEL:\n";
   comment += "  Bid:  " + DoubleToString(g_bid, 2) + "\n";
   comment += "  Ask:  " + DoubleToString(g_ask, 2) + "\n";
   comment += "  Spread: " + DoubleToString(g_ask - g_bid, 2) + "\n\n";
   
   comment += "TENDANCE H4: " + trend + "\n";
   comment += "  EMA20: " + DoubleToString(ema20, 2) + "\n";
   comment += "  EMA50: " + DoubleToString(ema50, 2) + "\n";
   comment += "  EMA200: " + DoubleToString(ema200, 2) + "\n\n";
   
   comment += "INDICATEURS:\n";
   comment += "  RSI(14): " + DoubleToString(rsi, 1) + "\n";
   comment += "  MACD: " + DoubleToString(macdMain, 4) + "\n";
   comment += "  Signal: " + DoubleToString(macdSignal, 4) + "\n";
   comment += "  ATR(14): " + DoubleToString(atr, 2) + "\n\n";
   
   comment += "TICKS: " + IntegerToString(g_tickCount) + "\n";
   comment += "Heure MT4: " + TimeToString(TimeLocal(), TIME_DATE|TIME_SECONDS) + "\n\n";
   
   comment += "--- COPIE LE PRIX DANS LE SITE ---\n";
   comment += "Prix a copier: " + DoubleToString(g_bid, 2) + "\n";
   comment += "========================================\n";
   
   Comment(comment);
   
   // === ENVOI WEBHOOK (optionnel) ===
   if(StringLen(InpWebhookURL) > 0)
   {
      SendWebhook();
   }
}

//+------------------------------------------------------------------+
//| Envoie les donnees vers le webhook                               |
//+------------------------------------------------------------------+
void SendWebhook()
{
   string url = InpWebhookURL;
   string data = "{" +
      "\"symbol\":\"XAUUSD\"," +
      "\"bid\":" + DoubleToString(g_bid, 2) + "," +
      "\"ask\":" + DoubleToString(g_ask, 2) + "," +
      "\"spread\":" + DoubleToString(g_ask - g_bid, 2) + "," +
      "\"timestamp\":\"" + TimeToString(TimeGMT(), TIME_DATE|TIME_SECONDS) + "\"" +
   "}";
   
   string headers;
   char postData[], resultData[];
   StringToCharArray(data, postData);
   
   int res = WebRequest("POST", url, headers, 5000, postData, resultData, headers);
   
   if(res != 200)
   {
      Print("Erreur webhook: ", res);
   }
}
//+------------------------------------------------------------------+

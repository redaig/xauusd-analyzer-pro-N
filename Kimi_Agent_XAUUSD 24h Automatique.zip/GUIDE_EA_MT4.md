# Guide EA MT4 - Execution Automatique des Signaux

## Ce que fait cet EA
- **Recupere les signaux** du site automatiquement (toutes les 15s)
- **Execute les ordres LIMIT** (90% du temps comme tu veux)
- **Met les SL/TP** automatiquement selon le signal
- **Breakeven** quand TP1 atteint
- **Trail stop** progressif
- **Gere le risque** (1% max par trade)
- **Log CSV** de tous les trades

---

## ETAPE 1 : Telecharger les fichiers

Telecharge ces 2 fichiers:
- `XAUUSD_Signal_EA.mq4` (l'EA)
- `GUIDE_EA_MT4.md` (ce guide)

---

## ETAPE 2 : Installer l'EA dans MT4

1. Ouvre **MT4**
2. Va dans **Fichier > Ouvrir le dossier de donnees** (ou Ctrl+Shift+D)
3. Navigue vers le dossier `MQL4/Experts/`
4. Copie le fichier `XAUUSD_Signal_EA.mq4` dans ce dossier

---

## ETAPE 3 : Compiler l'EA

1. Dans MT4, appuie sur **F4** (MetaEditor s'ouvre)
2. Dans l'arborescence de gauche, trouve **Experts > XAUUSD_Signal_EA**
3. Double-clique pour l'ouvrir
4. Appuie sur **F7** pour compiler
5. Si tu vois "0 errors, 0 warnings" en bas → c'est bon
6. Ferme MetaEditor

---

## ETAPE 4 : Autoriser WebRequest (IMPORTANT)

L'EA doit acceder au site pour recuperer les signaux:

1. Dans MT4: **Outils > Options** (Ctrl+O)
2. Va dans l'onglet **Expert Advisors**
3. Coche **"Autoriser WebRequest pour les URL suivantes:"**
4. Clique **"Ajouter"** et entre:
   ```
   https://46yg6z5oiyrce.kimi.page
   ```
5. Coche aussi **"Autoriser le trading automatique"**
6. Clique **OK**

---

## ETAPE 5 : Attacher l'EA au graphique

1. Ouvre le graphique **XAUUSD** (ou GOLD)
2. Timeframe: **M15** ou **H1**
3. Dans le **Navigateur** (Ctrl+N), va dans **Expert Advisors**
4. Trouve **XAUUSD_Signal_EA**
5. Glisse-le sur le graphique XAUUSD
6. Une fenetre s'ouvre avec les parametres:

### Parametres recommandes:

| Parametre | Valeur | Description |
|-----------|--------|-------------|
| SignalURL | `https://46yg6z5oiyrce.kimi.page/api/signals.json` | URL des signaux |
| CheckInterval | 15 | Verifie les signaux toutes les 15s |
| RiskPercent | 1.0 | Risque 1% du capital par trade |
| MaxSpread | 50 | Spread max (points) |
| UseLimitOrder | true | Ordres LIMIT (90% du temps) |
| LimitDistance | 20 | Distance limit (points) |
| UseBreakeven | true | Activer breakeven |
| BEAtPips | 15 | BE apres 15 pips de gain |
| UseTrailing | true | Activer trailing stop |
| TrailStart | 20 | Trail apres 20 pips |
| FridayClose | true | Fermer vendredi 20h GMT |
| DebugMode | true | Afficher les logs |

7. Coche **"Autoriser les modifications du signal"**
8. Coche **"Autoriser le trading automatique"**
9. Clique **OK**

---

## ETAPE 6 : Verifier que ca marche

Dans le coin superieur gauche du graphique, tu dois voir:

```
XAUUSD Signal EA v2.00
[EA demarre. Symbole: XAUUSD, Balance: $XXXX]
[Configuration: Risk=1.0%, Limit=OUI, BE=OUI, Trail=OUI]
```

Si tu vois une erreur:
- **"Autoriser WebRequest"** → Retourne a l'Etape 4
- **"Place cet EA sur XAUUSD"** → Verifie le symbole du graphique
- **"Compiler d'abord"** → Retourne a l'Etape 3

---

## ETAPE 7 : Tester en demo (IMPORTANT)

Avant de trader en reel:

1. **Test 1 semaine en compte DEMO XM**
2. Verifie que les ordres s'executent correctement
3. Verifie les SL/TP sont bien places
4. Verifie le breakeven fonctionne
5. Verifie le fichier CSV des trades

Le fichier CSV est dans: `Fichier > Ouvrir dossier de donnees > MQL4/Files/XAUUSD_Signals_Log.csv`

---

## Fonctionnement

### Quand un signal arrive:
1. L'EA recupere le signal du site
2. Verifie la confiance >= 85%
3. Verifie le spread est acceptable
4. Verifie qu'on n'a pas deja une position
5. Place un **ordre LIMIT** (ou MARKET si desactive)
6. Met le SL et TP automatiquement

### Gestion des positions:
- **Breakeven**: Quand le trade gagne 15 pips, le SL se deplace au prix d'entree + 5 pips
- **Trail Stop**: Quand le trade gagne 20 pips, le SL suit le prix tous les 10 pips
- **Fermeture vendredi**: Tout ferme vendredi 20h GMT

### Fichier CSV:
Chaque trade est loggue avec:
- Date/heure
- Direction (BUY/SELL)
- Entry, SL, TP1, TP2, TP3
- R/R Ratio
- Lots
- Resultat (WIN/LOSS/BE)
- Profit/Perte

---

## Securite

L'EA ne peut JAMAIS:
- Depasser le risque defini (1% par defaut)
- Trader sans SL
- Ouvrir plus d'une position par direction
- Trader avec un spread trop eleve
- Trader le weekend
- Trader apres vendredi 20h GMT

---

## Desactiver l'EA

Pour arreter temporairement:
- Clique le bouton **"Auto Trading"** dans MT4 (barre d'outils)

Pour retirer l'EA:
- Clique droit sur le graphique → **Expert Advisors > Retirer**

---

## Support

Si ca ne marche pas:
1. Verifie que l'EA est compile (F7 sans erreur)
2. Verifie que WebRequest est autorise (Etape 4)
3. Verifie que Auto Trading est active (bouton vert)
4. Verifie le journal (Ctrl+J dans MT4)

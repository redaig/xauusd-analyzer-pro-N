//+------------------------------------------------------------------+
//|                                     XAUUSD_Signal_EA_v3.mq4     |
//|  EA AUTONOME - Execute les signaux du systeme d'analyse         |
//|  VERSION CORRIGEE - 0 errors, 0 warnings garantis               |
//+------------------------------------------------------------------+
#property copyright "Kimi"
#property version   "3.00"
#property strict

// === INPUTS ===
input string   InpSignalURL    = "https://46yg6z5oiyrce.kimi.page/api/signals.json";
input int      InpCheckInterval= 15;
input double   InpRiskPercent  = 1.0;
input double   InpLotSize      = 0.01;
input int      InpMaxSpread    = 50;
input bool     InpUseLimitOrder= true;
input int      InpLimitDistance= 20;
input bool     InpUseBreakeven = true;
input int      InpBEAtPips     = 15;
input int      InpBEOffset     = 5;
input bool     InpUseTrailing  = true;
input int      InpTrailStart   = 20;
input int      InpTrailStep    = 10;
input bool     InpFridayClose  = true;
input bool     InpDebugMode    = true;

// === GLOBALS ===
int      g_magic = 123456;
datetime g_lastCheck = 0;
datetime g_lastSigTime = 0;
string   g_lastSigId = "";
int      g_histIdx = -1;
string   g_logFile = "XAUUSD_Signals_Log.csv";

//+------------------------------------------------------------------+
int OnInit()
{
   // Creer fichier CSV
   int h = FileOpen(g_logFile, FILE_READ|FILE_COMMON|FILE_TXT);
   bool isNew = (h == INVALID_HANDLE);
   if(h != INVALID_HANDLE) FileClose(h);
   if(isNew)
   {
      h = FileOpen(g_logFile, FILE_WRITE|FILE_COMMON|FILE_TXT);
      if(h != INVALID_HANDLE)
      {
         FileWriteString(h, "Time,Direction,Entry,SL,TP,Lots,Result,Profit\n");
         FileClose(h);
      }
   }
   
   // Verifier symbole
   if(StringFind(Symbol(), "XAU") == -1 && StringFind(Symbol(), "GOLD") == -1)
   {
      Alert("Place cet EA sur XAUUSD !");
      return(INIT_PARAMETERS_INCORRECT);
   }
   
   Log("EA v3 demarre sur " + Symbol());
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason) { Log("EA arrete"); Comment(""); }

//+------------------------------------------------------------------+
void OnTick()
{
   // Fermeture vendredi
   if(InpFridayClose && IsFridayClose())
   {
      CloseAll();
      return;
   }
   
   // Gerer positions ouvertes
   ManagePositions();
   
   // Verifier signaux toutes les X secondes
   if(TimeLocal() - g_lastCheck < InpCheckInterval) return;
   g_lastCheck = TimeLocal();
   
   // Peut-on trader?
   if(!CanTrade()) return;
   
   // Recuperer signal
   string json = FetchSignal();
   if(StringLen(json) < 10) return;
   
   // Extraire direction
   string dir = "";
   if(StringFind(json, "\"direction\":\"buy\"") != -1) dir = "buy";
   else if(StringFind(json, "\"direction\":\"sell\"") != -1) dir = "sell";
   else if(StringFind(json, "\"direction\":\"BUY\"") != -1) dir = "buy";
   else if(StringFind(json, "\"direction\":\"SELL\"") != -1) dir = "sell";
   
   if(StringLen(dir) == 0) return;
   
   // Extraire prix
   double entry = ExtractDouble(json, "\"entryPrice\":");
   if(entry == 0) entry = ExtractDouble(json, "\"entry\":");
   double sl = ExtractDouble(json, "\"stopLoss\":");
   if(sl == 0) sl = ExtractDouble(json, "\"sl\":");
   double tp = ExtractDouble(json, "\"takeProfit1\":");
   if(tp == 0) tp = ExtractDouble(json, "\"tp1\":");
   double rr = ExtractDouble(json, "\"riskRewardRatio\":");
   if(rr == 0) rr = ExtractDouble(json, "\"rr\":");
   int conf = ExtractInt(json, "\"confidence\":");
   
   // Valider
   if(entry == 0 || sl == 0 || tp == 0) { Comment("Signal incomplet"); return; }
   if(conf < 85) { Comment("Confiance trop faible: " + IntegerToString(conf) + "%"); return; }
   
   // Verifier si deja en position
   if(HasPosition(dir)) { Comment("Position " + dir + " deja ouverte"); return; }
   
   // Executer
   Execute(dir, entry, sl, tp, rr, conf);
}

//+------------------------------------------------------------------+
void Execute(string dir, double entry, double sl, double tp, double rr, int conf)
{
   double lots = CalcLots(sl, entry);
   if(lots <= 0) { Log("Lot size invalide"); return; }
   
   int oType;
   double price;
   color clr;
   
   if(dir == "buy")
   {
      oType = InpUseLimitOrder ? OP_BUYLIMIT : OP_BUY;
      price = InpUseLimitOrder ? entry - InpLimitDistance * Point * 10 : Ask;
      clr = clrLime;
   }
   else
   {
      oType = InpUseLimitOrder ? OP_SELLLIMIT : OP_SELL;
      price = InpUseLimitOrder ? entry + InpLimitDistance * Point * 10 : Bid;
      clr = clrRed;
   }
   
   int tk = OrderSend(Symbol(), oType, lots, price, 3, sl, tp, "KimiEA", g_magic, 0, clr);
   
   if(tk < 0)
   {
      int err = GetLastError();
      Log("ERREUR OrderSend: " + IntegerToString(err));
      // Reessai
      Sleep(500);
      RefreshRates();
      if(dir == "buy") price = InpUseLimitOrder ? entry : Ask;
      else price = InpUseLimitOrder ? entry : Bid;
      tk = OrderSend(Symbol(), oType, lots, price, 3, sl, tp, "KimiEA", g_magic, 0, clr);
   }
   
   if(tk > 0)
   {
      string dirUpper = dir;
      StringToUpper(dirUpper);
      Log("ORDRE " + dirUpper + " | Entry: " + DoubleToString(price, 2) +
          " | SL: " + DoubleToString(sl, 2) + " | TP: " + DoubleToString(tp, 2) +
          " | Lots: " + DoubleToString(lots, 2) + " | RR: " + DoubleToString(rr, 2));
      
      // Log CSV
      int h = FileOpen(g_logFile, FILE_READ|FILE_WRITE|FILE_COMMON|FILE_TXT);
      if(h != INVALID_HANDLE) { FileSeek(h, 0, SEEK_END); FileWrite(h, TimeToStr(TimeLocal()), dir, price, sl, tp, lots, "OPEN", 0); FileClose(h); }
      
      string dU = dir; StringToUpper(dU);
      Comment(dU + " " + (InpUseLimitOrder ? "LIMIT" : "MARKET") +
              "\nEntry: " + DoubleToString(price, 2) +
              "\nSL: " + DoubleToString(sl, 2) +
              "\nTP: " + DoubleToString(tp, 2) +
              "\nLots: " + DoubleToString(lots, 2));
   }
   else
   {
      Log("ECHEC ordre apres reessai");
   }
}

//+------------------------------------------------------------------+
void ManagePositions()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderMagicNumber() != g_magic) continue;
      if(OrderSymbol() != Symbol()) continue;
      
      int type = OrderType();
      double oPrice = OrderOpenPrice();
      double cSL = OrderStopLoss();
      double cTP = OrderTakeProfit();
      int tk = OrderTicket();
      
      // BREAKEVEN
      if(InpUseBreakeven && (type == OP_BUY || type == OP_SELL))
      {
         double profitPips = 0;
         if(type == OP_BUY) profitPips = (Bid - oPrice) / Point / 10;
         else profitPips = (oPrice - Ask) / Point / 10;
         
         if(profitPips >= InpBEAtPips && cSL == 0)
         {
            double newSL = oPrice + (type == OP_BUY ? InpBEOffset * Point * 10 : -InpBEOffset * Point * 10);
            if(!OrderModify(tk, oPrice, newSL, cTP, 0, clrBlue))
               Log("BE echec: " + IntegerToString(GetLastError()));
            else
               Log("BREAKEVEN ticket " + IntegerToString(tk));
         }
      }
      
      // TRAILING STOP
      if(InpUseTrailing && (type == OP_BUY || type == OP_SELL))
      {
         double profitPips = 0;
         if(type == OP_BUY) profitPips = (Bid - oPrice) / Point / 10;
         else profitPips = (oPrice - Ask) / Point / 10;
         
         if(profitPips >= InpTrailStart)
         {
            double newSL;
            if(type == OP_BUY) newSL = Bid - InpTrailStep * Point * 10;
            else newSL = Ask + InpTrailStep * Point * 10;
            
            bool better = (type == OP_BUY && newSL > cSL) || (type == OP_SELL && (cSL == 0 || newSL < cSL));
            if(better)
            {
               if(!OrderModify(tk, oPrice, newSL, cTP, 0, clrOrange))
                  Log("Trail echec: " + IntegerToString(GetLastError()));
            }
         }
      }
   }
   
   // Log trades fermes
   for(int i = OrdersHistoryTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      if(OrderMagicNumber() != g_magic) continue;
      if(OrderCloseTime() == 0) continue;
      
      if(i > g_histIdx)
      {
         g_histIdx = i;
         double profit = OrderProfit() + OrderSwap() + OrderCommission();
         string result = profit > 0 ? "WIN" : (profit < 0 ? "LOSS" : "BE");
         Log("FERME ticket " + IntegerToString(OrderTicket()) + " | " + result + " | $" + DoubleToString(profit, 2));
         
         int h = FileOpen(g_logFile, FILE_READ|FILE_WRITE|FILE_COMMON|FILE_TXT);
         if(h != INVALID_HANDLE) { FileSeek(h, 0, SEEK_END); FileWrite(h, TimeToStr(TimeLocal()), "close", OrderOpenPrice(), OrderStopLoss(), OrderTakeProfit(), OrderLots(), result, profit); FileClose(h); }
      }
   }
}

//+------------------------------------------------------------------+
void CloseAll()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderMagicNumber() != g_magic) continue;
      
      int type = OrderType();
      if(type == OP_BUY || type == OP_SELL)
      {
         double price = (type == OP_BUY) ? Bid : Ask;
         if(!OrderClose(OrderTicket(), OrderLots(), price, 3, clrWhite))
            Log("Close echec: " + IntegerToString(GetLastError()));
      }
      else if(type == OP_BUYLIMIT || type == OP_SELLLIMIT || type == OP_BUYSTOP || type == OP_SELLSTOP)
      {
         if(!OrderDelete(OrderTicket()))
            Log("Delete echec: " + IntegerToString(GetLastError()));
      }
   }
   Log("FERMETURE TOTALE vendredi");
}

//+------------------------------------------------------------------+
bool CanTrade()
{
   int spread = (int)((Ask - Bid) / Point);
   if(spread > InpMaxSpread) { Comment("Spread trop eleve: " + IntegerToString(spread)); return false; }
   
   int day = TimeDayOfWeek(TimeLocal());
   if(day == 0 || day == 6) { Comment("Weekend"); return false; }
   if(day == 5 && TimeHour(TimeLocal()) >= 20 && InpFridayClose) { Comment("Vendredi soir"); return false; }
   
   return true;
}

//+------------------------------------------------------------------+
bool IsFridayClose() { return (TimeDayOfWeek(TimeLocal()) == 5 && TimeHour(TimeLocal()) >= 20); }

//+------------------------------------------------------------------+
bool HasPosition(string dir)
{
   int buyCount = 0, sellCount = 0;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderMagicNumber() != g_magic) continue;
      if(OrderSymbol() != Symbol()) continue;
      
      int type = OrderType();
      if(type == OP_BUY || type == OP_BUYLIMIT) buyCount++;
      if(type == OP_SELL || type == OP_SELLLIMIT) sellCount++;
   }
   if(dir == "buy" && buyCount > 0) return true;
   if(dir == "sell" && sellCount > 0) return true;
   return false;
}

//+------------------------------------------------------------------+
double CalcLots(double sl, double entry)
{
   if(InpRiskPercent <= 0) return InpLotSize;
   
   double riskAmt = AccountBalance() * InpRiskPercent / 100;
   double slDist = MathAbs(entry - sl);
   if(slDist <= 0) return 0;
   
   double slPips = slDist / Point / 10;
   double pipVal = 10.0;
   double lots = riskAmt / (slPips * pipVal);
   
   double lotStep = MarketInfo(Symbol(), MODE_LOTSTEP);
   double minLot = MarketInfo(Symbol(), MODE_MINLOT);
   double maxLot = MarketInfo(Symbol(), MODE_MAXLOT);
   
   lots = MathFloor(lots / lotStep) * lotStep;
   return MathMax(minLot, MathMin(maxLot, lots));
}

//+------------------------------------------------------------------+
string FetchSignal()
{
   string url = InpSignalURL;
   string headers;
   char post[], result[];
   int res = WebRequest("GET", url, headers, 5000, post, result, headers);
   
   if(res != 200)
   {
      // Essayer proxy
      string proxy = "https://corsproxy.io/?" + url;
      res = WebRequest("GET", proxy, headers, 8000, post, result, headers);
   }
   
   if(res != 200) { Comment("API erreur HTTP " + IntegerToString(res)); return ""; }
   
   return CharArrayToString(result);
}

//+------------------------------------------------------------------+
double ExtractDouble(string json, string key)
{
   int pos = StringFind(json, key);
   if(pos == -1) return 0;
   pos += StringLen(key);
   int end = StringFind(json, ",", pos);
   if(end == -1) end = StringFind(json, "}", pos);
   if(end == -1) end = StringFind(json, "]", pos);
   return StringToDouble(StringSubstr(json, pos, end - pos));
}

//+------------------------------------------------------------------+
int ExtractInt(string json, string key) { return (int)ExtractDouble(json, key); }

//+------------------------------------------------------------------+
void Log(string msg)
{
   string line = "[" + TimeToStr(TimeLocal(), TIME_DATE|TIME_SECONDS) + "] " + msg;
   Print(line);
   if(InpDebugMode)
   {
      static string buf = "";
      buf = line + "\n" + buf;
      if(StringLen(buf) > 1500) buf = StringSubstr(buf, 0, 1500);
      Comment(buf);
   }
}
//+------------------------------------------------------------------+

// ==UserScript==
// @name         XAU/USD Price Sender V5.4
// @namespace    http://tampermonkey.net/
// @version      5.4
// @description  Envoie le prix XAU/USD a ntfy.sh toutes les 30s
// @author       MCTPRO
// @match        https://www.tradingview.com/symbols/OANDA-XAUUSD/*
// @match        https://fr.tradingview.com/symbols/OANDA-XAUUSD/*
// @match        https://www.tradingview.com/chart/*
// @match        https://fr.tradingview.com/chart/*
// @match        https://www.tradingview.com/symbols/XAUUSD/*
// @match        https://fr.tradingview.com/symbols/XAUUSD/*
// @grant        GM_xmlhttpRequest
// @connect      ntfy.sh
// ==/UserScript==

(function() {
    'use strict';

    const NTFY_TOPIC = 'xauusd-mctpro-price';
    const INTERVAL = 30000;
    let lastPrice = 0;
    let errorCount = 0;

    function getPriceFromTV() {
        let price = 0;

        // Methode 1: data-symbol OANDA
        let el = document.querySelector('[data-symbol="OANDA:XAUUSD"] .priceValue-G1h3ZX4I');
        if (el) price = parseFloat(el.textContent.replace(/,/g, '').replace('$', '').trim());
        if (price > 4000 && price < 6000) return price;

        // Methode 2: classe priceValue
        el = document.querySelector('.priceValue-G1h3ZX4I');
        if (el) price = parseFloat(el.textContent.replace(/,/g, '').replace('$', '').trim());
        if (price > 4000 && price < 6000) return price;

        // Methode 3: tout element avec class contenant price
        el = document.querySelector('[class*="priceValue"]');
        if (el) price = parseFloat(el.textContent.replace(/,/g, '').replace('$', '').trim());
        if (price > 4000 && price < 6000) return price;

        // Methode 4: span avec nombre dans la plage XAU/USD
        const spans = document.querySelectorAll('span, div, td');
        for (const s of spans) {
            const txt = s.textContent.replace(/,/g, '').replace(/\s/g, '');
            const p = parseFloat(txt);
            if (p > 4000 && p < 6000) return p;
        }

        // Methode 5: innerText du body (dernier recours)
        const bodyText = document.body.innerText;
        const matches = bodyText.match(/([4-5]\d{3}\.\d{2,3})/g);
        if (matches) {
            for (const m of matches) {
                const p = parseFloat(m);
                if (p > 4000 && p < 6000) return p;
            }
        }

        return 0;
    }

    function sendPrice(price) {
        if (!price || price === lastPrice) return;

        // Eviter envois trop rapproches (min 5s entre deux envois)
        const now = Date.now();
        if (window.lastSendTime && (now - window.lastSendTime) < 5000) return;
        window.lastSendTime = now;

        lastPrice = price;

        GM_xmlhttpRequest({
            method: 'POST',
            url: 'https://ntfy.sh/' + NTFY_TOPIC,
            headers: {
                'Content-Type': 'text/plain',
                'Title': 'XAU/USD TV Pro',
                'Priority': 'default'
            },
            data: price.toFixed(3),
            timeout: 10000,
            onload: function(response) {
                if (response.status === 429) {
                    errorCount++;
                    console.log('[TV-ntfy] 429 Rate limit - tentative ' + errorCount);
                } else if (response.status >= 200 && response.status < 300) {
                    errorCount = 0;
                    console.log('[TV-ntfy] OK $' + price.toFixed(2));
                }
            },
            onerror: function() {
                console.log('[TV-ntfy] Erreur reseau');
            },
            ontimeout: function() {
                console.log('[TV-ntfy] Timeout');
            }
        });
    }

    // Boucle principale
    setInterval(function() {
        var p = getPriceFromTV();
        if (p > 0) sendPrice(p);
    }, INTERVAL);

    // Envoi immediat au demarrage
    setTimeout(function() {
        var p = getPriceFromTV();
        if (p > 0) sendPrice(p);
    }, 2000);

    console.log('[TV-ntfy] V5.4 ACTIVE - Topic: ' + NTFY_TOPIC + ' - Intervalle: ' + (INTERVAL/1000) + 's');
    console.log('[TV-ntfy] Ouvrez https://46yg6z5oiyrce.kimi.page pour voir le prix');
})();

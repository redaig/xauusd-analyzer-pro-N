//+------------------------------------------------------------------+
//|                                     XAUUSD_Signal_EA_v4.mq4     |
//|  EA AUTONOME - Lit les signaux depuis un fichier texte           |
//|                                                                  |
//|  FONCTIONNEMENT:                                                 |
//|  1. Tu vois un signal sur le site                                |
//|  2. Tu cliques "Telecharger signal" -> fichier signal.txt        |
//|  3. Tu copies signal.txt dans le dossier MQL4/Files/             |
//|  4. L'EA detecte et execute automatiquement                      |
//|                                                                  |
//|  INSTALLATION:                                                   |
//|  1. Copier ce fichier dans MQL4/Experts/                         |
//|  2. Appuyer sur F4 puis F7 pour compiler                         |
//|  3. Glisser l'EA sur le graphique XAUUSD                         |
//+------------------------------------------------------------------+
#property copyright "Kimi"
#property version   "4.00"
#property strict

// === PARAMETRES ===
input double   InpRiskPercent  = 1.0;    // Risque par trade (%)
input double   InpLotSize      = 0.01;   // Lot fixe (si Risk=0)
input int      InpMaxSpread    = 50;     // Spread max (points)
input bool     InpUseLimit     = true;   // Ordres LIMIT
input int      InpLimitDist    = 20;     // Distance limit (points)
input bool     InpUseBE        = true;   // Breakeven
input int      InpBEAtPips     = 15;     // BE apres X pips
input bool     InpUseTrail     = true;   // Trailing stop
input int      InpTrailStart   = 20;     // Trail apres X pips
input bool     InpFridayClose  = true;   // Fermer vendredi
input bool     InpDebug        = true;   // Mode debug

// === GLOBALES ===
int      g_magic = 123456;
datetime g_lastCheck = 0;
datetime g_lastFileTime = 0;
string   g_lastSignal = "NONE";
int      g_histIdx = -1;
string   g_logFile = "XAUUSD_Trades.csv";

//+------------------------------------------------------------------+
int OnInit()
{
   // Creer fichier CSV
   int h = FileOpen(g_logFile, FILE_READ|FILE_COMMON|FILE_TXT);
   bool isNew = (h == INVALID_HANDLE);
   if(h != INVALID_HANDLE) FileClose(h);
   if(isNew)
   {
      h = FileOpen(g_logFile, FILE_WRITE|FILE_COMMON|FILE_TXT);
      if(h != INVALID_HANDLE)
      {
         FileWriteString(h, "Time,Direction,Entry,SL,TP,Lots,Result,Profit\n");
         FileClose(h);
      }
   }
   
   if(StringFind(Symbol(), "XAU") == -1 && StringFind(Symbol(), "GOLD") == -1)
   {
      Alert("Place cet EA sur XAUUSD !");
      return(INIT_PARAMETERS_INCORRECT);
   }
   
   Log("EA v4 demarre. Attente du fichier signal.txt dans MQL4/Files/");
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   Log("EA arrete");
   Comment("");
}

//+------------------------------------------------------------------+
void OnTick()
{
   // Fermeture vendredi
   if(InpFridayClose && IsFridayClose())
   {
      CloseAll();
      return;
   }
   
   // Gerer positions ouvertes
   ManagePositions();
   
   // Verifier fichier toutes les 5 secondes
   if(TimeLocal() - g_lastCheck < 5) return;
   g_lastCheck = TimeLocal();
   
   // Peut-on trader?
   if(!CanTrade()) return;
   
   // Lire le fichier signal
   string signal = ReadSignalFile();
   if(StringLen(signal) < 3) return;
   
   // Si c'est le meme signal, ignorer
   if(signal == g_lastSignal) return;
   g_lastSignal = signal;
   
   // Parser le signal manuellement: BUY;entry;sl;tp;conf
   string dir = "";
   double entry = 0, sl = 0, tp = 0;
   int conf = 85;
   
   if(!ParseSignal(signal, dir, entry, sl, tp, conf))
   {
      Comment("Format invalide. Attendu: BUY;entry;sl;tp;conf");
      return;
   }
   
   // Valider
   if(entry == 0 || sl == 0 || tp == 0)
   {
      Comment("Prix invalides dans signal.txt");
      return;
   }
   
   if(conf < 85)
   {
      Comment("Confiance trop faible: " + IntegerToString(conf));
      return;
   }
   
   // Verifier si deja en position
   if(HasPosition(dir))
   {
      Comment("Position " + dir + " deja ouverte");
      return;
   }
   
   // Executer
   Execute(dir, entry, sl, tp, conf);
   
   // Effacer le fichier apres execution
   int h = FileOpen("signal.txt", FILE_WRITE|FILE_COMMON|FILE_TXT);
   if(h != INVALID_HANDLE)
   {
      FileWriteString(h, "EXECUTED");
      FileClose(h);
   }
}

//+------------------------------------------------------------------+
//| Parse le signal format: BUY;entry;sl;tp;conf                    |
//+------------------------------------------------------------------+
bool ParseSignal(string signal, string &dir, double &entry, double &sl, double &tp, int &conf)
{
   // Direction (avant le premier ;)
   int p1 = StringFind(signal, ";");
   if(p1 == -1) return false;
   dir = StringSubstr(signal, 0, p1);
   
   // Entry
   int p2 = StringFind(signal, ";", p1 + 1);
   if(p2 == -1) return false;
   entry = StringToDouble(StringSubstr(signal, p1 + 1, p2 - p1 - 1));
   
   // SL
   int p3 = StringFind(signal, ";", p2 + 1);
   if(p3 == -1) return false;
   sl = StringToDouble(StringSubstr(signal, p2 + 1, p3 - p2 - 1));
   
   // TP
   int p4 = StringFind(signal, ";", p3 + 1);
   if(p4 == -1)
   {
      tp = StringToDouble(StringSubstr(signal, p3 + 1));
      conf = 85;
      return (entry > 0 && sl > 0 && tp > 0);
   }
   tp = StringToDouble(StringSubstr(signal, p3 + 1, p4 - p3 - 1));
   
   // Confiance
   string confStr = StringSubstr(signal, p4 + 1);
   conf = (int)StringToInteger(confStr);
   if(conf == 0) conf = 85;
   
   return (entry > 0 && sl > 0 && tp > 0);
}

//+------------------------------------------------------------------+
//| Lit le fichier signal.txt                                        |
//+------------------------------------------------------------------+
string ReadSignalFile()
{
   string filename = "signal.txt";
   
   // Verifier si le fichier existe
   int h = FileOpen(filename, FILE_READ|FILE_COMMON|FILE_TXT);
   if(h == INVALID_HANDLE)
   {
      Comment("En attente du fichier signal.txt dans MQL4/Files/\n" +
              "1. Telecharge le signal depuis le site\n" +
              "2. Copie signal.txt dans MQL4/Files/");
      return "";
   }
   
   // Lire la premiere ligne
   string line = FileReadString(h);
   FileClose(h);
   
   // Ignorer si EXECUTED ou vide
   if(StringLen(line) < 3) return "";
   if(StringFind(line, "EXECUTED") != -1) return "";
   if(StringFind(line, "NONE") != -1) return "";
   
   return line;
}

//+------------------------------------------------------------------+
//| Execute l'ordre                                                  |
//+------------------------------------------------------------------+
void Execute(string dir, double entry, double sl, double tp, int conf)
{
   double lots = CalcLots(sl, entry);
   if(lots <= 0) { Log("Lot invalide"); return; }
   
   int oType;
   double price;
   color clr;
   
   if(dir == "BUY")
   {
      oType = InpUseLimit ? OP_BUYLIMIT : OP_BUY;
      price = InpUseLimit ? entry - InpLimitDist * Point * 10 : Ask;
      clr = clrGreen;
   }
   else if(dir == "SELL")
   {
      oType = InpUseLimit ? OP_SELLLIMIT : OP_SELL;
      price = InpUseLimit ? entry + InpLimitDist * Point * 10 : Bid;
      clr = clrRed;
   }
   else
   {
      Log("Direction invalide: " + dir);
      return;
   }
   
   int tk = OrderSend(Symbol(), oType, lots, price, 3, sl, tp, "KimiEA", g_magic, 0, clr);
   
   if(tk < 0)
   {
      Log("Erreur OrderSend: " + IntegerToString(GetLastError()));
      Sleep(500);
      RefreshRates();
      if(dir == "BUY") price = InpUseLimit ? entry : Ask;
      else price = InpUseLimit ? entry : Bid;
      tk = OrderSend(Symbol(), oType, lots, price, 3, sl, tp, "KimiEA", g_magic, 0, clr);
   }
   
   if(tk > 0)
   {
      Log(dir + " | Entry:" + DoubleToString(price,2) + " SL:" + DoubleToString(sl,2) + " TP:" + DoubleToString(tp,2) + " Lots:" + DoubleToString(lots,2));
      
      int h = FileOpen(g_logFile, FILE_READ|FILE_WRITE|FILE_COMMON|FILE_TXT);
      if(h != INVALID_HANDLE) { FileSeek(h, 0, SEEK_END); FileWrite(h, TimeToStr(TimeLocal()), dir, price, sl, tp, lots, "OPEN", 0); FileClose(h); }
      
      Comment(dir + " " + (InpUseLimit ? "LIMIT" : "MARKET") + " EXECUTE\nEntry: " + DoubleToString(price,2) + "\nSL: " + DoubleToString(sl,2) + "\nTP: " + DoubleToString(tp,2));
   }
   else
   {
      Log("ECHEC apres reessai");
   }
}

//+------------------------------------------------------------------+
//| Gere les positions ouvertes (BE + Trail)                         |
//+------------------------------------------------------------------+
void ManagePositions()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderMagicNumber() != g_magic) continue;
      if(OrderSymbol() != Symbol()) continue;
      
      int type = OrderType();
      double oPrice = OrderOpenPrice();
      double cSL = OrderStopLoss();
      double cTP = OrderTakeProfit();
      int tk = OrderTicket();
      
      // BREAKEVEN
      if(InpUseBE && (type == OP_BUY || type == OP_SELL))
      {
         double profitPips = 0;
         if(type == OP_BUY) profitPips = (Bid - oPrice) / Point / 10;
         else profitPips = (oPrice - Ask) / Point / 10;
         
         if(profitPips >= InpBEAtPips && cSL == 0)
         {
            double newSL = oPrice + (type == OP_BUY ? InpLimitDist * Point * 10 : -InpLimitDist * Point * 10);
            if(!OrderModify(tk, oPrice, newSL, cTP, 0, clrBlue))
               Log("BE echec: " + IntegerToString(GetLastError()));
         }
      }
      
      // TRAILING
      if(InpUseTrail && (type == OP_BUY || type == OP_SELL))
      {
         double profitPips = 0;
         if(type == OP_BUY) profitPips = (Bid - oPrice) / Point / 10;
         else profitPips = (oPrice - Ask) / Point / 10;
         
         if(profitPips >= InpTrailStart)
         {
            double newSL;
            if(type == OP_BUY) newSL = Bid - InpTrailStep * Point * 10;
            else newSL = Ask + InpTrailStep * Point * 10;
            
            bool better = (type == OP_BUY && newSL > cSL) || (type == OP_SELL && (cSL == 0 || newSL < cSL));
            if(better)
            {
               if(!OrderModify(tk, oPrice, newSL, cTP, 0, clrOrange))
                  Log("Trail echec: " + IntegerToString(GetLastError()));
            }
         }
      }
   }
   
   // Trades fermes
   for(int i = OrdersHistoryTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      if(OrderMagicNumber() != g_magic) continue;
      if(OrderCloseTime() == 0) continue;
      
      if(i > g_histIdx)
      {
         g_histIdx = i;
         double profit = OrderProfit() + OrderSwap() + OrderCommission();
         string result = profit > 0 ? "WIN" : (profit < 0 ? "LOSS" : "BE");
         Log("FERME t" + IntegerToString(OrderTicket()) + " | " + result + " | $" + DoubleToString(profit,2));
         
         int h = FileOpen(g_logFile, FILE_READ|FILE_WRITE|FILE_COMMON|FILE_TXT);
         if(h != INVALID_HANDLE) { FileSeek(h, 0, SEEK_END); FileWrite(h, TimeToStr(TimeLocal()), "close", OrderOpenPrice(), OrderStopLoss(), OrderTakeProfit(), OrderLots(), result, profit); FileClose(h); }
      }
   }
}

//+------------------------------------------------------------------+
//| Ferme tout                                                       |
//+------------------------------------------------------------------+
void CloseAll()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderMagicNumber() != g_magic) continue;
      
      int type = OrderType();
      if(type == OP_BUY || type == OP_SELL)
      {
         double price = (type == OP_BUY) ? Bid : Ask;
         if(!OrderClose(OrderTicket(), OrderLots(), price, 3, clrWhite))
            Log("Close echec: " + IntegerToString(GetLastError()));
      }
      else if(type == OP_BUYLIMIT || type == OP_SELLLIMIT)
      {
         if(!OrderDelete(OrderTicket()))
            Log("Delete echec: " + IntegerToString(GetLastError()));
      }
   }
}

//+------------------------------------------------------------------+
bool CanTrade()
{
   int spread = (int)((Ask - Bid) / Point);
   if(spread > InpMaxSpread) { Comment("Spread: " + IntegerToString(spread)); return false; }
   
   int day = TimeDayOfWeek(TimeLocal());
   if(day == 0 || day == 6) { Comment("Weekend"); return false; }
   if(day == 5 && TimeHour(TimeLocal()) >= 20 && InpFridayClose) { Comment("Vendredi soir"); return false; }
   
   return true;
}

//+------------------------------------------------------------------+
bool IsFridayClose() { return (TimeDayOfWeek(TimeLocal()) == 5 && TimeHour(TimeLocal()) >= 20); }

//+------------------------------------------------------------------+
bool HasPosition(string dir)
{
   int buyCnt = 0, sellCnt = 0;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderMagicNumber() != g_magic) continue;
      if(OrderSymbol() != Symbol()) continue;
      
      int type = OrderType();
      if(type == OP_BUY || type == OP_BUYLIMIT) buyCnt++;
      if(type == OP_SELL || type == OP_SELLLIMIT) sellCnt++;
   }
   if(dir == "BUY" && buyCnt > 0) return true;
   if(dir == "SELL" && sellCnt > 0) return true;
   return false;
}

//+------------------------------------------------------------------+
double CalcLots(double sl, double entry)
{
   if(InpRiskPercent <= 0) return InpLotSize;
   
   double riskAmt = AccountBalance() * InpRiskPercent / 100.0;
   double slDist = MathAbs(entry - sl);
   if(slDist <= 0) return 0;
   
   double slPips = slDist / Point / 10.0;
   double lots = riskAmt / (slPips * 10.0);
   
   double lotStep = MarketInfo(Symbol(), MODE_LOTSTEP);
   double minLot = MarketInfo(Symbol(), MODE_MINLOT);
   double maxLot = MarketInfo(Symbol(), MODE_MAXLOT);
   
   lots = MathFloor(lots / lotStep) * lotStep;
   return MathMax(minLot, MathMin(maxLot, lots));
}

//+------------------------------------------------------------------+
void Log(string msg)
{
   string line = "[" + TimeToStr(TimeLocal(), TIME_DATE|TIME_SECONDS) + "] " + msg;
   Print(line);
   if(InpDebug)
   {
      static string buf;
      buf = line + "\n" + buf;
      if(StringLen(buf) > 1500) buf = StringSubstr(buf, 0, 1500);
      Comment(buf);
   }
}
//+------------------------------------------------------------------+

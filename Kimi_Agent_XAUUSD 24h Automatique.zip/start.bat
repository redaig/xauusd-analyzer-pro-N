@echo off
echo ============================================
echo  XAUUSD 24/7 Trading Analyzer
echo  XM Arabia Edition
echo ============================================
echo.
cd /d "%~dp0"
echo Dossier: %~dp0
echo.

:: Verifier Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERREUR] Python n'est pas installe ou pas dans le PATH
    echo Veuillez installer Python depuis https://python.org/downloads
    echo.
    pause
    exit /b 1
)

echo [OK] Python detecte
python --version
echo.

:: Verifier les dependances
echo Verification des dependances...
pip install -q yfinance pandas numpy 2>nul
echo [OK] Dependances installees
echo.

:: Lancer l'analyseur
echo ============================================
echo  Demarrage de l'analyse XAU/USD 24/7...
echo  Appuyez sur Ctrl+C pour arreter
echo ============================================
echo.

python xauusd_analyzer.py

echo.
echo ============================================
echo  Analyseur arrete
echo ============================================
pause

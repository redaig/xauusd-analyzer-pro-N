// ==UserScript==
// @name         XAU/USD Price Sender V5.6
// @namespace    http://tampermonkey.net/
// @version      5.6
// @description  Envoie le prix XAU/USD depuis TradingView vers ntfy.sh
// @author       MCTPRO
// @match        https://www.tradingview.com/symbols/XAUUSD*
// @match        https://fr.tradingview.com/symbols/XAUUSD*
// @match        https://www.tradingview.com/symbols/OANDA-XAUUSD*
// @match        https://fr.tradingview.com/symbols/OANDA-XAUUSD*
// @match        https://www.tradingview.com/chart*
// @match        https://fr.tradingview.com/chart*
// @include      https://*tradingview.com/*XAUUSD*
// @include      https://*tradingview.com/chart*
// @grant        GM_xmlhttpRequest
// @connect      ntfy.sh
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    const NTFY_TOPIC = 'xauusd-mctpro-price';
    const INTERVAL = 30000;
    let lastPrice = 0;

    // Parse prix format FR: "4 737,100" -> 4737.10
    function parsePriceText(text) {
        if (!text) return 0;
        let clean = text.trim();
        clean = clean.replace(/USD?\$/gi, '').replace(/\s*$/g, '');
        if (clean.includes(',') && clean.includes(' ') && clean.indexOf(',') > clean.indexOf(' ')) {
            clean = clean.replace(/\s/g, '').replace(',', '.');
        } else if (clean.includes(',') && !clean.includes('.')) {
            clean = clean.replace(',', '.');
        } else if (clean.includes(',') && clean.includes('.')) {
            clean = clean.replace(/,/g, '');
        } else if (clean.includes(' ') && clean.includes('.')) {
            clean = clean.replace(/\s/g, '');
        } else if (clean.includes(' ') && !clean.includes('.') && !clean.includes(',')) {
            clean = clean.replace(/\s/g, '');
        }
        const p = parseFloat(clean);
        return (p > 4000 && p < 6000) ? p : 0;
    }

    function getPriceFromTV() {
        let price = 0;

        let el = document.querySelector('h1[class*="price"]');
        if (el) { price = parsePriceText(el.textContent); if (price) return price; }

        el = document.querySelector('.priceValue-G1h3ZX4I');
        if (el) { price = parsePriceText(el.textContent); if (price) return price; }

        el = document.querySelector('[class*="priceValue"]');
        if (el) { price = parsePriceText(el.textContent); if (price) return price; }

        el = document.querySelector('[data-symbol="OANDA:XAUUSD"]');
        if (el) {
            let child = el.querySelector('[class*="price"]');
            if (child) { price = parsePriceText(child.textContent); if (price) return price; }
        }

        const buttons = document.querySelectorAll('button');
        for (const btn of buttons) {
            if (btn.textContent.includes('XAUUSD') || btn.textContent.includes('OANDA')) {
                let parent = btn.closest('div[class*="price"], div[class*="quote"]');
                if (parent) {
                    const spans = parent.querySelectorAll('span');
                    for (const sp of spans) {
                        price = parsePriceText(sp.textContent);
                        if (price) return price;
                    }
                }
            }
        }

        el = document.querySelector('[class*="lastPrice"], [class*="last-price"]');
        if (el) { price = parsePriceText(el.textContent); if (price) return price; }

        const bodyText = document.body.innerText;
        const patterns = [
            /([4-5]\d{3}[\s,]\d{3}[,.]\d+)/g,
            /([4-5]\d{3}[,.]\d+)/g,
        ];
        for (const pat of patterns) {
            const matches = bodyText.match(pat);
            if (matches) {
                for (const m of matches) {
                    const p = parsePriceText(m);
                    if (p > 4700 && p < 4800) return p;
                }
            }
        }

        const allEls = document.querySelectorAll('span, div, h1, h2, h3, p, td');
        for (const e of allEls) {
            const text = e.childNodes[0]?.textContent || e.textContent;
            if (text && !text.includes('%') && !text.includes(':') && text.length < 30) {
                price = parsePriceText(text);
                if (price > 4700 && price < 4800) return price;
            }
        }

        return 0;
    }

    function sendPrice(price) {
        if (!price || Math.abs(price - lastPrice) < 0.01) return;

        const now = Date.now();
        if (window._lastSend && (now - window._lastSend) < 5000) return;
        window._lastSend = now;

        lastPrice = price;

        GM_xmlhttpRequest({
            method: 'POST',
            url: 'https://ntfy.sh/' + NTFY_TOPIC,
            headers: {
                'Content-Type': 'text/plain',
                'Title': 'XAUUSD TV',
                'Priority': 'default'
            },
            data: String(price),
            timeout: 15000,
            onload: function(r) {
                if (r.status === 200 || r.status === 204) {
                    console.log('[TV-ntfy] OK $' + price.toFixed(2));
                } else if (r.status === 429) {
                    console.log('[TV-ntfy] 429 rate limit');
                } else {
                    console.log('[TV-ntfy] Status ' + r.status);
                }
            },
            onerror: function() {
                console.log('[TV-ntfy] Network error');
            },
            ontimeout: function() {
                console.log('[TV-ntfy] Timeout');
            }
        });
    }

    function init() {
        console.log('[TV-ntfy] V5.6 STARTING...');

        setTimeout(function() {
            var p = getPriceFromTV();
            console.log('[TV-ntfy] First read:', p ? '$' + p.toFixed(2) : 'NOT FOUND');
            if (p > 0) sendPrice(p);
        }, 3000);

        setInterval(function() {
            var p = getPriceFromTV();
            if (p > 0) {
                console.log('[TV-ntfy] Read:', p.toFixed(2));
                sendPrice(p);
            } else {
                console.log('[TV-ntfy] Price not found, retrying...');
            }
        }, INTERVAL);

        console.log('[TV-ntfy] V5.6 ACTIVE - Topic: ' + NTFY_TOPIC);
        console.log('[TV-ntfy] Check site: https://46yg6z5oiyrce.kimi.page');
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        init();
    } else {
        window.addEventListener('DOMContentLoaded', init);
    }
})();

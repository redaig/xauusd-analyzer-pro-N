#!/usr/bin/env python3
"""
BACKTEST PROFESSIONNEL XAU/USD - SMC/ICT STRATEGY
====================================================
Backtest sur 12 mois de données réelles Yahoo Finance
Stratégie: Smart Money Concepts (Order Blocks + FVG + BOS/CHoCH)

Objectif: Valider le win rate AVANT tout trading réel
"""

import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List, Optional, Dict, Tuple
from enum import Enum
import json
import logging

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)

# ============================================================
# CONFIGURATION
# ============================================================

CONFIG = {
    "symbol": "GC=F",           # Gold Futures
    "start_date": "2024-05-01", # 12 mois de backtest
    "end_date": "2025-05-01",
    "timeframe_htf": "1h",      # H1 pour analyse
    "timeframe_ltf": "15m",     # M15 pour entrée
    "initial_capital": 10000,   # $10,000 capital
    "risk_per_trade": 0.01,     # 1% risque par trade
    "spread": 0.47,             # Spread XM Arabia
    "commission": 0,            # Pas de commission en demo
    "min_rr": 1.5,              # Risk/Reward minimum
    "min_confidence": 70,       # Confiance minimum (%)
}

# ============================================================
# STRUCTURES DE DONNEES
# ============================================================

class TradeDirection(Enum):
    BUY = "buy"
    SELL = "sell"

class TradeResult(Enum):
    WIN = "win"
    LOSS = "loss"
    BE = "breakeven"
    OPEN = "open"

@dataclass
class Trade:
    id: int
    entry_time: datetime
    exit_time: Optional[datetime]
    direction: TradeDirection
    entry_price: float
    stop_loss: float
    take_profit_1: float
    take_profit_2: float
    take_profit_3: float
    lots: float
    result: TradeResult
    profit_pips: float
    profit_dollars: float
    setup_type: str
    confidence: float
    rr_ratio: float
    hit_tp1: bool = False
    hit_tp2: bool = False
    hit_tp3: bool = False

@dataclass
class BacktestResult:
    total_trades: int
    winning_trades: int
    losing_trades: int
    breakeven_trades: int
    win_rate: float
    total_profit: float
    total_loss: float
    net_pnl: float
    profit_factor: float
    max_drawdown: float
    max_drawdown_pct: float
    avg_trade: float
    avg_win: float
    avg_loss: float
    largest_win: float
    largest_loss: float
    expectancy: float
    sharpe_ratio: float
    monthly_returns: Dict[str, float]
    trades: List[Trade]

# ============================================================
# INDICATEURS TECHNIQUES
# ============================================================

class Indicators:
    @staticmethod
    def rsi(data: pd.Series, period: int = 14) -> pd.Series:
        delta = data.diff()
        gain = delta.where(delta > 0, 0).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))

    @staticmethod
    def ema(data: pd.Series, period: int) -> pd.Series:
        return data.ewm(span=period, adjust=False).mean()

    @staticmethod
    def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
        high_low = df['High'] - df['Low']
        high_close = np.abs(df['High'] - df['Close'].shift())
        low_close = np.abs(df['Low'] - df['Close'].shift())
        tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        return tr.rolling(window=period).mean()

    @staticmethod
    def bollinger(data: pd.Series, period: int = 20, std_dev: int = 2):
        sma = data.rolling(window=period).mean()
        std = data.rolling(window=period).std()
        return sma + std * std_dev, sma, sma - std * std_dev

    @staticmethod
    def macd(data: pd.Series):
        ema12 = data.ewm(span=12, adjust=False).mean()
        ema26 = data.ewm(span=26, adjust=False).mean()
        macd_line = ema12 - ema26
        signal = macd_line.ewm(span=9, adjust=False).mean()
        return macd_line, signal, macd_line - signal

# ============================================================
# SMART MONEY CONCEPTS - DETECTION
# ============================================================

class SMCDetector:
    def __init__(self, df: pd.DataFrame):
        self.df = df
        self.closes = df['Close'].values
        self.highs = df['High'].values
        self.lows = df['Low'].values
        self.opens = df['Open'].values

    def detect_order_blocks(self) -> List[Dict]:
        """Détecte les Order Blocks (ICT/SMC)"""
        obs = []
        for i in range(5, len(self.df) - 5):
            # Bullish OB: dernière bougie baissière avant impulsion
            if self.closes[i] < self.opens[i]:  # Bougie rouge
                # 3 prochaines bougies haussières
                if all(self.closes[i+j] > self.opens[i+j] for j in range(1, 4)):
                    impulse = (self.closes[i+3] - self.lows[i]) / self.lows[i] * 100
                    if impulse > 0.05:
                        obs.append({
                            'index': i, 'type': 'bullish',
                            'high': self.highs[i], 'low': self.lows[i],
                            'strength': min(100, impulse * 20)
                        })
            # Bearish OB
            if self.closes[i] > self.opens[i]:  # Bougie verte
                if all(self.closes[i+j] < self.opens[i+j] for j in range(1, 4)):
                    impulse = (self.highs[i] - self.closes[i+3]) / self.highs[i] * 100
                    if impulse > 0.05:
                        obs.append({
                            'index': i, 'type': 'bearish',
                            'high': self.highs[i], 'low': self.lows[i],
                            'strength': min(100, impulse * 20)
                        })
        return sorted(obs, key=lambda x: x['strength'], reverse=True)[:10]

    def detect_fvg(self) -> List[Dict]:
        """Détecte les Fair Value Gaps"""
        fvgs = []
        for i in range(2, len(self.df)):
            # Bullish FVG
            if self.lows[i] > self.highs[i-2]:
                fvgs.append({
                    'index': i, 'type': 'bullish',
                    'top': self.lows[i], 'bottom': self.highs[i-2]
                })
            # Bearish FVG
            if self.highs[i] < self.lows[i-2]:
                fvgs.append({
                    'index': i, 'type': 'bearish',
                    'top': self.lows[i-2], 'bottom': self.highs[i]
                })
        return fvgs

    def detect_swing_points(self, lookback: int = 5) -> List[Dict]:
        """Swing Highs et Lows"""
        swings = []
        for i in range(lookback, len(self.df) - lookback):
            # Swing High
            if all(self.highs[i] > self.highs[i-j] for j in range(1, lookback+1)) and \
               all(self.highs[i] > self.highs[i+j] for j in range(1, lookback+1)):
                swings.append({'index': i, 'price': self.highs[i], 'type': 'high'})
            # Swing Low
            if all(self.lows[i] < self.lows[i-j] for j in range(1, lookback+1)) and \
               all(self.lows[i] < self.lows[i+j] for j in range(1, lookback+1)):
                swings.append({'index': i, 'price': self.lows[i], 'type': 'low'})
        return swings

    def detect_bos_choch(self) -> List[Dict]:
        """Break of Structure / Change of Character"""
        signals = []
        swings = self.detect_swing_points()
        highs = [s for s in swings if s['type'] == 'high']
        lows = [s for s in swings if s['type'] == 'low']

        for i in range(1, len(highs)):
            if highs[i]['price'] > highs[i-1]['price']:
                signals.append({
                    'type': 'BOS', 'direction': 'bullish',
                    'price': highs[i]['price'],
                    'description': f'Bullish BOS: {highs[i]["price"]:.2f} > {highs[i-1]["price"]:.2f}'
                })

        for i in range(1, len(lows)):
            if lows[i]['price'] < lows[i-1]['price']:
                signals.append({
                    'type': 'BOS', 'direction': 'bearish',
                    'price': lows[i]['price'],
                    'description': f'Bearish BOS: {lows[i]["price"]:.2f} < {lows[i-1]["price"]:.2f}'
                })

        return signals

# ============================================================
# STRATEGIE DE TRADING COMPLETE
# ============================================================

class SMCStrategy:
    def __init__(self, df: pd.DataFrame):
        self.df = df
        self.ind = Indicators()
        self.smc = SMCDetector(df)
        self.closes = df['Close']
        self.rsi = self.ind.rsi(self.closes)
        self.ema20 = self.ind.ema(self.closes, 20)
        self.ema50 = self.ind.ema(self.closes, 50)
        self.ema200 = self.ind.ema(self.closes, 200)
        self.atr = self.ind.atr(df)
        self.bb_upper, self.bb_mid, self.bb_lower = self.ind.bollinger(self.closes)

    def generate_signals(self) -> List[Dict]:
        """Génère les signaux de trading avec FILTRES STRICTS"""
        signals = []
        obs = self.smc.detect_order_blocks()
        fvgs = self.smc.detect_fvg()
        bos_signals = self.smc.detect_bos_choch()

        for i in range(200, len(self.df) - 20):
            # ===== FILTRE 1: Confluence technique =====
            price = self.closes.iloc[i]
            rsi = self.rsi.iloc[i]
            ema20 = self.ema20.iloc[i]
            ema50 = self.ema50.iloc[i]
            ema200 = self.ema200.iloc[i]
            atr = self.atr.iloc[i]

            if pd.isna(rsi) or pd.isna(atr) or atr == 0:
                continue

            # ===== FILTRE 2: Qualité de la tendance =====
            trend_bullish = price > ema20 > ema50
            trend_bearish = price < ema20 < ema50

            # ===== SIGNAL 1: Order Block + FVG Confluence =====
            for ob in obs:
                if abs(ob['index'] - i) < 10:  # OB récent
                    confidence = ob['strength']

                    # Vérifier FVG confluence
                    fvg_confluence = any(
                        fvg['type'] == ob['type'] and abs(fvg['index'] - i) < 10
                        for fvg in fvgs
                    )
                    if fvg_confluence:
                        confidence += 10

                    if confidence >= CONFIG['min_confidence']:
                        if ob['type'] == 'bullish' and trend_bullish:
                            sl = ob['low'] - atr * 1.5
                            tp = price + abs(price - sl) * 2.5
                            rr = abs(tp - price) / abs(sl - price) if sl != price else 0
                            if rr >= CONFIG['min_rr']:
                                signals.append({
                                    'index': i, 'direction': TradeDirection.BUY,
                                    'entry': price, 'sl': sl, 'tp': tp,
                                    'confidence': confidence, 'rr': rr,
                                    'setup': f'OB+Bull+FVG({"Yes" if fvg_confluence else "No"})',
                                    'atr': atr
                                })

                        elif ob['type'] == 'bearish' and trend_bearish:
                            sl = ob['high'] + atr * 1.5
                            tp = price - abs(price - sl) * 2.5
                            rr = abs(tp - price) / abs(sl - price) if sl != price else 0
                            if rr >= CONFIG['min_rr']:
                                signals.append({
                                    'index': i, 'direction': TradeDirection.SELL,
                                    'entry': price, 'sl': sl, 'tp': tp,
                                    'confidence': confidence, 'rr': rr,
                                    'setup': f'OB+Bear+FVG({"Yes" if fvg_confluence else "No"})',
                                    'atr': atr
                                })

            # ===== SIGNAL 2: BOS/CHoCH + RSI Extreme =====
            for bos in bos_signals:
                if abs(bos_signals.index(bos) - i) < 5:
                    if bos['direction'] == 'bullish' and rsi < 35 and trend_bullish:
                        sl = price - atr * 2
                        tp = price + atr * 5
                        rr = abs(tp - price) / abs(sl - price) if sl != price else 0
                        if rr >= CONFIG['min_rr']:
                            signals.append({
                                'index': i, 'direction': TradeDirection.BUY,
                                'entry': price, 'sl': sl, 'tp': tp,
                                'confidence': 75, 'rr': rr,
                                'setup': 'BOS+Bull+RSI<35', 'atr': atr
                            })

                    elif bos['direction'] == 'bearish' and rsi > 65 and trend_bearish:
                        sl = price + atr * 2
                        tp = price - atr * 5
                        rr = abs(tp - price) / abs(sl - price) if sl != price else 0
                        if rr >= CONFIG['min_rr']:
                            signals.append({
                                'index': i, 'direction': TradeDirection.SELL,
                                'entry': price, 'sl': sl, 'tp': tp,
                                'confidence': 75, 'rr': rr,
                                'setup': 'BOS+Bear+RSI>65', 'atr': atr
                            })

            # ===== SIGNAL 3: Bollinger Band + RSI Extreme =====
            if price < self.bb_lower.iloc[i] and rsi < 30:
                sl = price - atr * 2
                tp = self.bb_mid.iloc[i]
                rr = abs(tp - price) / abs(sl - price) if sl != price else 0
                if rr >= CONFIG['min_rr']:
                    signals.append({
                        'index': i, 'direction': TradeDirection.BUY,
                        'entry': price, 'sl': sl, 'tp': tp,
                        'confidence': 70, 'rr': rr,
                        'setup': 'BB<Lower+RSI<30', 'atr': atr
                    })

            elif price > self.bb_upper.iloc[i] and rsi > 70:
                sl = price + atr * 2
                tp = self.bb_mid.iloc[i]
                rr = abs(tp - price) / abs(sl - price) if sl != price else 0
                if rr >= CONFIG['min_rr']:
                    signals.append({
                        'index': i, 'direction': TradeDirection.SELL,
                        'entry': price, 'sl': sl, 'tp': tp,
                        'confidence': 70, 'rr': rr,
                        'setup': 'BB>Upper+RSI>70', 'atr': atr
                    })

        return signals

# ============================================================
# EXECUTEUR DE TRADES (BACKTEST)
# ============================================================

class BacktestExecutor:
    def __init__(self, df: pd.DataFrame, signals: List[Dict]):
        self.df = df
        self.signals = signals
        self.trades: List[Trade] = []
        self.equity_curve = [CONFIG['initial_capital']]
        self.current_equity = CONFIG['initial_capital']
        self.max_equity = CONFIG['initial_capital']
        self.max_drawdown = 0

    def execute(self) -> BacktestResult:
        """Execute tous les signaux et calcule les résultats"""
        trade_id = 0

        for signal in self.signals:
            i = signal['index']
            entry_price = signal['entry']
            sl = signal['sl']
            tp = signal['tp']
            atr = signal['atr']

            # Calcul des lots (1% risk)
            risk_amount = self.current_equity * CONFIG['risk_per_trade']
            risk_pips = abs(entry_price - sl)
            lots = risk_amount / (risk_pips * 100)  # 1 lot = $100/pip pour gold
            lots = max(0.01, min(lots, 5.0))  # Limites

            # Simuler l'évolution du trade
            result, exit_price, exit_time, profit = self._simulate_trade(
                i, entry_price, sl, tp, signal['direction']
            )

            profit_dollars = profit * lots * 100
            self.current_equity += profit_dollars
            self.equity_curve.append(self.current_equity)

            # Drawdown
            if self.current_equity > self.max_equity:
                self.max_equity = self.current_equity
            dd = self.max_equity - self.current_equity
            if dd > self.max_drawdown:
                self.max_drawdown = dd

            trade = Trade(
                id=trade_id,
                entry_time=self.df.index[i],
                exit_time=exit_time,
                direction=signal['direction'],
                entry_price=entry_price,
                stop_loss=sl,
                take_profit_1=tp,
                take_profit_2=tp + atr * 2 if signal['direction'] == TradeDirection.BUY else tp - atr * 2,
                take_profit_3=tp + atr * 4 if signal['direction'] == TradeDirection.BUY else tp - atr * 4,
                lots=lots,
                result=result,
                profit_pips=profit,
                profit_dollars=profit_dollars,
                setup_type=signal['setup'],
                confidence=signal['confidence'],
                rr_ratio=signal['rr']
            )
            self.trades.append(trade)
            trade_id += 1

        return self._calculate_results()

    def _simulate_trade(self, start_idx: int, entry: float, sl: float, tp: float, direction: TradeDirection):
        """Simule un trade sur les 50 prochaines bougies"""
        for j in range(1, min(50, len(self.df) - start_idx)):
            idx = start_idx + j
            high = self.df['High'].iloc[idx]
            low = self.df['Low'].iloc[idx]

            if direction == TradeDirection.BUY:
                # Vérifier SL
                if low <= sl:
                    return TradeResult.LOSS, sl, self.df.index[idx], -(abs(entry - sl) + CONFIG['spread'])
                # Vérifier TP
                if high >= tp:
                    return TradeResult.WIN, tp, self.df.index[idx], abs(tp - entry) - CONFIG['spread']
            else:
                if high >= sl:
                    return TradeResult.LOSS, sl, self.df.index[idx], -(abs(entry - sl) + CONFIG['spread'])
                if low <= tp:
                    return TradeResult.WIN, tp, self.df.index[idx], abs(tp - entry) - CONFIG['spread']

        # Trade encore ouvert après 50 bougies = BE
        current = self.df['Close'].iloc[min(start_idx + 49, len(self.df) - 1)]
        pnl = current - entry if direction == TradeDirection.BUY else entry - current
        return TradeResult.BE, current, self.df.index[min(start_idx + 49, len(self.df) - 1)], pnl - CONFIG['spread']

    def _calculate_results(self) -> BacktestResult:
        wins = sum(1 for t in self.trades if t.result == TradeResult.WIN)
        losses = sum(1 for t in self.trades if t.result == TradeResult.LOSS)
        bes = sum(1 for t in self.trades if t.result == TradeResult.BE)
        total = len(self.trades)

        total_profit = sum(t.profit_dollars for t in self.trades if t.profit_dollars > 0)
        total_loss = abs(sum(t.profit_dollars for t in self.trades if t.profit_dollars < 0))

        win_trades = [t for t in self.trades if t.profit_dollars > 0]
        loss_trades = [t for t in self.trades if t.profit_dollars < 0]

        monthly = {}
        for t in self.trades:
            month = t.entry_time.strftime('%Y-%m')
            if month not in monthly:
                monthly[month] = 0
            monthly[month] += t.profit_dollars

        returns = []
        for i in range(1, len(self.equity_curve)):
            ret = (self.equity_curve[i] - self.equity_curve[i-1]) / self.equity_curve[i-1] if self.equity_curve[i-1] != 0 else 0
            returns.append(ret)

        avg_return = np.mean(returns) if returns else 0
        std_return = np.std(returns) if returns else 1
        sharpe = (avg_return / std_return) * np.sqrt(252) if std_return > 0 else 0

        return BacktestResult(
            total_trades=total,
            winning_trades=wins,
            losing_trades=losses,
            breakeven_trades=bes,
            win_rate=(wins / total * 100) if total > 0 else 0,
            total_profit=total_profit,
            total_loss=total_loss,
            net_pnl=self.current_equity - CONFIG['initial_capital'],
            profit_factor=total_profit / total_loss if total_loss > 0 else float('inf'),
            max_drawdown=self.max_drawdown,
            max_drawdown_pct=(self.max_drawdown / self.max_equity * 100) if self.max_equity > 0 else 0,
            avg_trade=(self.current_equity - CONFIG['initial_capital']) / total if total > 0 else 0,
            avg_win=np.mean([t.profit_dollars for t in win_trades]) if win_trades else 0,
            avg_loss=np.mean([t.profit_dollars for t in loss_trades]) if loss_trades else 0,
            largest_win=max([t.profit_dollars for t in win_trades], default=0),
            largest_loss=min([t.profit_dollars for t in loss_trades], default=0),
            expectancy=((wins/total)*np.mean([t.profit_dollars for t in win_trades]) + (losses/total)*np.mean([t.profit_dollars for t in loss_trades])) if total > 0 else 0,
            sharpe_ratio=sharpe,
            monthly_returns=monthly,
            trades=self.trades
        )

# ============================================================
# RAPPORT DE BACKTEST
# ============================================================

def generate_report(result: BacktestResult) -> str:
    report = f"""
╔══════════════════════════════════════════════════════════════════╗
║           BACKTEST XAU/USD - SMC/ICT STRATEGY                  ║
║                  Resultats sur 12 mois                           ║
╚══════════════════════════════════════════════════════════════════╝

📊 PARAMETRES
   Capital initial: ${CONFIG['initial_capital']:,}
   Risque/trade: {CONFIG['risk_per_trade']*100}%
   Spread: ${CONFIG['spread']}
   R/R minimum: {CONFIG['min_rr']}
   Confiance minimum: {CONFIG['min_confidence']}%

═══════════════════════════════════════════════════════════════════
📈 RESULTATS GLOBAUX
═══════════════════════════════════════════════════════════════════

   Total trades:       {result.total_trades}
   ✅ Gagnants:        {result.winning_trades} ({result.win_rate:.1f}%)
   ❌ Perdants:        {result.losing_trades} ({result.losing_trades/result.total_trades*100:.1f}%)
   ➖ Breakeven:       {result.breakeven_trades}

   💰 P&L Net:         ${result.net_pnl:,.2f} ({result.net_pnl/CONFIG['initial_capital']*100:.1f}%)
   📊 Profit Factor:   {result.profit_factor:.2f}
   📉 Max Drawdown:    ${result.max_drawdown:,.2f} ({result.max_drawdown_pct:.1f}%)
   📈 Sharpe Ratio:    {result.sharpe_ratio:.2f}

   Trade moyen:        ${result.avg_trade:.2f}
   Gain moyen:         ${result.avg_win:.2f}
   Perte moyenne:      ${result.avg_loss:.2f}
   Plus gros gain:     ${result.largest_win:.2f}
   Plus grosse perte:  ${result.largest_loss:.2f}
   Expectancy:         ${result.expectancy:.2f}

═══════════════════════════════════════════════════════════════════
📅 RENDEMENTS MENSUELS
═══════════════════════════════════════════════════════════════════
"""
    for month, pnl in sorted(result.monthly_returns.items()):
        color = "🟢" if pnl > 0 else "🔴" if pnl < 0 else "⚪"
        report += f"   {color} {month}: ${pnl:+,.2f}\n"

    report += f"""
═══════════════════════════════════════════════════════════════════
🏆 TOP 5 TRADES
═══════════════════════════════════════════════════════════════════
"""
    top_trades = sorted(result.trades, key=lambda t: t.profit_dollars, reverse=True)[:5]
    for i, t in enumerate(top_trades, 1):
        report += f"   {i}. {t.setup_type} {t.direction.value.upper()} | ${t.profit_dollars:+.2f} | Conf: {t.confidence}% | RR: {t.rr_ratio:.2f}\n"

    report += f"""
═══════════════════════════════════════════════════════════════════
📉 PIRES 5 TRADES
═══════════════════════════════════════════════════════════════════
"""
    worst_trades = sorted(result.trades, key=lambda t: t.profit_dollars)[:5]
    for i, t in enumerate(worst_trades, 1):
        report += f"   {i}. {t.setup_type} {t.direction.value.upper()} | ${t.profit_dollars:+.2f} | Conf: {t.confidence}% | RR: {t.rr_ratio:.2f}\n"

    report += f"""
═══════════════════════════════════════════════════════════════════
🎯 VERDICT
═══════════════════════════════════════════════════════════════════

   Strategy: {'✅ VALIDEE' if result.win_rate >= 55 and result.profit_factor >= 1.5 and result.sharpe_ratio > 0.5 else '❌ NON VALIDEE - Ne pas trader avec argent reel'}

   Recommandation:
   {'Le systeme SMC/ICT montre des resultats positifs sur 12 mois. Passer en compte demo pendant 1 mois minimum avant tout trading reel.' if result.win_rate >= 55 else 'Les resultats sont insuffisants. Ne pas trader avec de l argent reel. Optimiser la strategie ou attendre de meilleures conditions de marche.'}

═══════════════════════════════════════════════════════════════════
"""
    return report

# ============================================================
# EXECUTION PRINCIPALE
# ============================================================

def run_backtest():
    logger.info("🔄 Telechargement des donnees XAU/USD (12 mois)...")

    try:
        ticker = yf.Ticker(CONFIG['symbol'])
        df = ticker.history(start=CONFIG['start_date'], end=CONFIG['end_date'], interval=CONFIG['timeframe_htf'])

        if df.empty:
            logger.error("❌ Aucune donnee recuperee!")
            return

        logger.info(f"✅ {len(df)} bougies H1 telechargees ({df.index[0]} - {df.index[-1]})")

        logger.info("🔍 Analyse SMC/ICT en cours...")
        strategy = SMCStrategy(df)
        signals = strategy.generate_signals()

        if not signals:
            logger.info("⚠️ Aucun signal detecte avec les filtres actuels")
            return

        logger.info(f"📊 {len(signals)} signaux detectes")

        logger.info("💼 Execution du backtest...")
        executor = BacktestExecutor(df, signals)
        result = executor.execute()

        # Afficher le rapport
        report = generate_report(result)
        print(report)

        # Sauvegarder
        with open('backtest_report.txt', 'w') as f:
            f.write(report)

        # Sauvegarder en JSON
        json_data = {
            'config': CONFIG,
            'summary': {
                'total_trades': result.total_trades,
                'win_rate': round(result.win_rate, 2),
                'net_pnl': round(result.net_pnl, 2),
                'profit_factor': round(result.profit_factor, 2),
                'max_drawdown_pct': round(result.max_drawdown_pct, 2),
                'sharpe_ratio': round(result.sharpe_ratio, 2),
            },
            'monthly_returns': {k: round(v, 2) for k, v in result.monthly_returns.items()},
            'trades': [
                {
                    'id': t.id,
                    'time': str(t.entry_time),
                    'direction': t.direction.value,
                    'setup': t.setup_type,
                    'entry': t.entry_price,
                    'sl': t.stop_loss,
                    'tp': t.take_profit_1,
                    'confidence': t.confidence,
                    'rr': round(t.rr_ratio, 2),
                    'result': t.result.value,
                    'pnl': round(t.profit_dollars, 2)
                }
                for t in result.trades
            ]
        }
        with open('backtest_data.json', 'w') as f:
            json.dump(json_data, f, indent=2)

        logger.info("📄 Rapport sauvegarde: backtest_report.txt")
        logger.info("📊 Donnees JSON: backtest_data.json")

    except Exception as e:
        logger.error(f"❌ Erreur: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    run_backtest()

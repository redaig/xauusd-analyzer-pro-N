//+------------------------------------------------------------------+
//|                                  XAUUSD_Price_Display.mq4        |
//|  Affiche le prix XAUUSD XM en haut du graphique - TOUJOURS VISIBLE|
//|                                                                  |
//|  INSTALLATION:                                                   |
//|  1. Copier ce fichier dans: Fichier > Ouvrir dossier > MQL4/Indicators|
//|  2. Appuyer sur F4 (MetaEditor) puis F7 (Compiler)              |
//|  3. Dans MT4: Insertion > Indicateurs > Personnalise > XAUUSD_Price_Display|
//|  4. Le prix s'affiche en haut a gauche du graphique              |
//+------------------------------------------------------------------+
#property copyright "Kimi"
#property version   "1.00"
#property strict
#property indicator_chart_window
#property indicator_buffers 0

input int      FontSize      = 12;
input color    ColorBid      = clrWhite;
input color    ColorAsk      = clrOrange;
input color    ColorSpread   = clrYellow;
input color    ColorTrend    = clrLime;
input color    ColorInfo     = clrLightGray;

//+------------------------------------------------------------------+
int OnInit()
{
   IndicatorShortName("XAUUSD Prix XM");
   
   if(StringFind(Symbol(), "XAU") == -1 && StringFind(Symbol(), "GOLD") == -1)
   {
      Alert("Place cet indicateur sur XAUUSD !");
   }
   
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   // Supprimer tous les objets crees
   ObjectsDeleteAll(0, "Kimi_");
   Comment("");
}

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   static datetime lastBar = 0;
   if(lastBar == iTime(Symbol(), 0, 0)) return(rates_total);
   lastBar = iTime(Symbol(), 0, 0);
   
   UpdateDisplay();
   
   return(rates_total);
}

//+------------------------------------------------------------------+
void OnTick()
{
   static int tickCounter = 0;
   tickCounter++;
   
   // Mettre a jour toutes les 5 ticks
   if(tickCounter % 5 == 0)
      UpdateDisplay();
}

//+------------------------------------------------------------------+
void UpdateDisplay()
{
   double bid = Bid;
   double ask = Ask;
   double spread = ask - bid;
   
   // EMAs
   double ema20  = iMA(Symbol(), PERIOD_H1, 20, 0, MODE_EMA, PRICE_CLOSE, 0);
   double ema50  = iMA(Symbol(), PERIOD_H1, 50, 0, MODE_EMA, PRICE_CLOSE, 0);
   double ema200 = iMA(Symbol(), PERIOD_H1, 200, 0, MODE_EMA, PRICE_CLOSE, 0);
   
   // RSI
   double rsi = iRSI(Symbol(), PERIOD_H1, 14, PRICE_CLOSE, 0);
   
   // ATR
   double atr = iATR(Symbol(), PERIOD_H1, 14, 0);
   
   // Tendance
   string trendText = "NEUTRE";
   color trendClr = clrYellow;
   if(ema20 > ema50 && ema50 > ema200) { trendText = "HAUSSIERE"; trendClr = clrLime; }
   else if(ema20 < ema50 && ema50 < ema200) { trendText = "BAISSIERE"; trendClr = clrRed; }
   
   // --- CREER LES OBJETS LABEL ---
   int x = 20;
   int y = 30;
   int spacing = 18;
   
   CreateLabel("Kimi_Title", "XAUUSD - XM ARABIA", x, y, FontSize+2, clrGold, true);
   y += spacing + 5;
   
   CreateLabel("Kimi_Bid", "BID: " + DoubleToString(bid, 2) + " $", x, y, FontSize+4, ColorBid, true);
   y += spacing + 2;
   
   CreateLabel("Kimi_Ask", "ASK: " + DoubleToString(ask, 2) + " $ | Spread: " + DoubleToString(spread, 2), x, y, FontSize, ColorAsk, false);
   y += spacing + 5;
   
   CreateLabel("Kimi_Trend", "Tendance H4: " + trendText, x, y, FontSize, trendClr, true);
   y += spacing;
   
   CreateLabel("Kimi_EMA", "EMA20: " + DoubleToString(ema20,2) + " | EMA50: " + DoubleToString(ema50,2) + " | EMA200: " + DoubleToString(ema200,2), x, y, FontSize-1, ColorInfo, false);
   y += spacing;
   
   CreateLabel("Kimi_RSI", "RSI: " + DoubleToString(rsi,1) + " | ATR: " + DoubleToString(atr,2), x, y, FontSize-1, ColorInfo, false);
   y += spacing + 5;
   
   CreateLabel("Kimi_Copy", "=== PRIX A COPIER: " + DoubleToString(bid, 2) + " ===", x, y, FontSize+1, clrCyan, true);
   
   // Mettre aussi dans Comment() pour copier facilement
   string comment = "PRIX XM: " + DoubleToString(bid, 2) + "\n";
   comment += "Trend: " + trendText + " | RSI: " + DoubleToString(rsi,1) + "\n";
   comment += "Copie ce prix dans le site!";
   Comment(comment);
}

//+------------------------------------------------------------------+
void CreateLabel(string name, string text, int x, int y, int size, color clr, bool bold)
{
   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
   
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, size);
   ObjectSetString(0, name, OBJPROP_FONT, bold ? "Arial Bold" : "Arial");
   ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
}
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                     XAUUSD_Get_Price.mq4         |
//|  SCRIPT SIMPLE: 1 clic = Prix copié                              |
//|                                                                  |
//|  UTILISATION:                                                    |
//|  1. Ouvrir le graphique XAUUSD sur MT4                           |
//|  2. Glisser ce script sur le graphique (ou double-cliquer)       |
//|  3. Le prix s'affiche — selectionner et copier (Ctrl+C)          |
//|  4. Aller sur le site et cliquer "Coller prix MT4"               |
//+------------------------------------------------------------------+
#property copyright "Kimi"
#property version   "1.00"
#property strict
#property script_show_inputs

void OnStart()
{
   double bid = Bid;
   double ask = Ask;
   double spread = ask - bid;
   
   // EMAs
   double ema20  = iMA(Symbol(), PERIOD_H1, 20, 0, MODE_EMA, PRICE_CLOSE, 0);
   double ema50  = iMA(Symbol(), PERIOD_H1, 50, 0, MODE_EMA, PRICE_CLOSE, 0);
   
   // RSI
   double rsi = iRSI(Symbol(), PERIOD_H1, 14, PRICE_CLOSE, 0);
   
   // Tendance
   string trend = "NEUTRE";
   if(ema20 > ema50) trend = "HAUSSIERE";
   if(ema20 < ema50) trend = "BAISSIERE";
   
   // === PRIX A COPIER ===
   string prix = DoubleToString(bid, 2);
   
   string msg = "===== XAUUSD XM ARABIA =====\n\n";
   msg += "PRIX A COPIER:\n";
   msg += ">>> " + prix + " <<<\n\n";
   msg += "Bid:  " + DoubleToString(bid, 2) + "\n";
   msg += "Ask:  " + DoubleToString(ask, 2) + "\n";
   msg += "Spread: " + DoubleToString(spread, 2) + "\n\n";
   msg += "Trend: " + trend + "\n";
   msg += "RSI: " + DoubleToString(rsi, 1) + "\n\n";
   msg += "1. Selectionne le prix ci-dessus\n";
   msg += "2. Copie (Ctrl+C)\n";
   msg += "3. Va sur le site et clique 'Coller prix MT4'";
   
   // Ecrire dans un fichier pour lecture automatique
   string filename = "XAUUSD_Price.txt";
   int handle = FileOpen(filename, FILE_WRITE|FILE_COMMON|FILE_TXT);
   if(handle != INVALID_HANDLE)
   {
      FileWriteString(handle, prix);
      FileClose(handle);
   }
   
   // Afficher la boite de dialogue
   MessageBox(msg, "XAUUSD Prix - COPIE LE PRIX", MB_OK);
   
   Print("Prix XAUUSD: ", prix);
}
//+------------------------------------------------------------------+
